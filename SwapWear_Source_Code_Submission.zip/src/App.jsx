import Notifications from "./pages/Notifications";
import SwapCalculator from "./pages/SwapCalculator";
import Profile from "./pages/Profile";
import { BrowserRouter, Routes, Route } from "react-router-dom";

import Home from "./pages/Home";
import Login from "./pages/Login";
import Register from "./pages/Register";
import Dashboard from "./pages/Dashboard";
import Browse from "./pages/Browse";
import ListClothing from "./pages/ListClothing";
import ItemDetails from "./pages/ItemDetails";
import SwapRequests from "./pages/SwapRequests";
import Chat from "./pages/Chat";
import Admin from "./pages/Admin";
import MyListings from "./pages/MyListings";
import Wishlist from "./pages/Wishlist";

import ProtectedRoute from "./ProtectedRoute";

function App() {
  return (
    <BrowserRouter>
      <Routes>

        {/* =========================
            PUBLIC ROUTES
        ========================== */}

        <Route path="/" element={<Home />} />
        <Route
  path="/swap-calculator"
  element={<SwapCalculator />}
/>
<Route
  path="/notifications"
  element={
    <ProtectedRoute>
      <Notifications />
    </ProtectedRoute>
  }
/>

        <Route path="/login" element={<Login />} />

        <Route path="/register" element={<Register />} />

        <Route path="/browse" element={<Browse />} />

        <Route path="/wishlist" element={<Wishlist />} />

        <Route
          path="/item/:id"
          element={<ItemDetails />}
        />


        {/* =========================
            PROTECTED ROUTES
        ========================== */}

        <Route
          path="/dashboard"
          element={
            <ProtectedRoute>
              <Dashboard />
            </ProtectedRoute>
          }
        />

        <Route
          path="/list-clothing"
          element={
            <ProtectedRoute>
              <ListClothing />
            </ProtectedRoute>
          }
        />

        <Route
          path="/my-listings"
          element={
            <ProtectedRoute>
              <MyListings />
            </ProtectedRoute>
          }
        />

        <Route
          path="/swap-requests"
          element={
            <ProtectedRoute>
              <SwapRequests />
            </ProtectedRoute>
          }
        />

        <Route
          path="/chat"
          element={
            <ProtectedRoute>
              <Chat />
            </ProtectedRoute>
          }
        />
        <Route
  path="/profile"
  element={
    <ProtectedRoute>
      <Profile />
    </ProtectedRoute>
  }
/>

        <Route
          path="/admin"
          element={
            <ProtectedRoute>
              <Admin />
            </ProtectedRoute>
          }
        />

      </Routes>
    </BrowserRouter>
  );
}

export default App;