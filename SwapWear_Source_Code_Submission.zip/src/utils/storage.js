
const STORAGE_KEYS = {
  USERS: "swapwear_users",
  LEGACY_USER: "swapwear_user",
  CURRENT_USER: "swapwear_current_user",
  LISTINGS: "swapwear_listings",
  SWAP_REQUESTS: "swapwear_swap_requests",
  MESSAGES: "swapwear_messages",
  NOTIFICATIONS: "swapwear_notifications",
};

// Normalize email addresses
export const normalizeEmail = (email = "") =>
  String(email).trim().toLowerCase();

// Safely read JSON from localStorage
export function readStorage(key, fallback = null) {
  try {
    const value = localStorage.getItem(key);

    if (value === null) return fallback;

    return JSON.parse(value);
  } catch (error) {
    console.error(`Error reading ${key}:`, error);
    return fallback;
  }
}

// Safely write JSON to localStorage
export function writeStorage(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch (error) {
    console.error(`Error saving ${key}:`, error);
    return false;
  }
}

// Current user
export function getCurrentUser() {
  return readStorage(STORAGE_KEYS.CURRENT_USER, null);
}

export function setCurrentUser(user) {
  return writeStorage(STORAGE_KEYS.CURRENT_USER, user);
}

export function clearCurrentUser() {
  try {
    localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    return true;
  } catch (error) {
    console.error("Error clearing current user:", error);
    return false;
  }
}

// Registered users
export function getUsers() {
  let users = readStorage(STORAGE_KEYS.USERS, []);

  if (!Array.isArray(users)) {
    users = [];
  }

  // Migrate an older single-user account
  if (users.length === 0) {
    const oldUser = readStorage(
      STORAGE_KEYS.LEGACY_USER,
      null
    );

    if (oldUser?.email) {
      users = [oldUser];
      writeStorage(STORAGE_KEYS.USERS, users);
    }
  }

  return users;
}

export function saveUsers(users) {
  if (!Array.isArray(users)) return false;

  const saved = writeStorage(STORAGE_KEYS.USERS, users);

  if (saved) {
    if (users.length > 0) {
      writeStorage(
        STORAGE_KEYS.LEGACY_USER,
        users[users.length - 1]
      );
    } else {
      try {
        localStorage.removeItem(STORAGE_KEYS.LEGACY_USER);
      } catch (error) {
        console.error("Error clearing legacy user:", error);
      }
    }
  }

  return saved;
}

// Clothing listings
export function getListings() {
  const listings = readStorage(
    STORAGE_KEYS.LISTINGS,
    []
  );

  return Array.isArray(listings) ? listings : [];
}

export function saveListings(listings) {
  if (!Array.isArray(listings)) return false;

  return writeStorage(STORAGE_KEYS.LISTINGS, listings);
}

// Wishlist
export function getWishlistKey(email) {
  return `swapwear_wishlist_${normalizeEmail(email)}`;
}

export function getWishlist(email) {
  if (!email) return [];

  const wishlist = readStorage(
    getWishlistKey(email),
    []
  );

  return Array.isArray(wishlist) ? wishlist : [];
}

export function saveWishlist(email, wishlist) {
  if (!email || !Array.isArray(wishlist)) {
    return false;
  }

  return writeStorage(
    getWishlistKey(email),
    wishlist
  );
}

// Swap requests
export function getSwapRequests() {
  const requests = readStorage(
    STORAGE_KEYS.SWAP_REQUESTS,
    []
  );

  return Array.isArray(requests) ? requests : [];
}

export function saveSwapRequests(requests) {
  if (!Array.isArray(requests)) return false;

  return writeStorage(
    STORAGE_KEYS.SWAP_REQUESTS,
    requests
  );
}

// Chat messages
export function getMessages() {
  const messages = readStorage(
    STORAGE_KEYS.MESSAGES,
    []
  );

  return Array.isArray(messages) ? messages : [];
}

export function saveMessages(messages) {
  if (!Array.isArray(messages)) return false;

  return writeStorage(
    STORAGE_KEYS.MESSAGES,
    messages
  );
}

// Notifications
export function getNotifications() {
  const notifications = readStorage(
    STORAGE_KEYS.NOTIFICATIONS,
    []
  );

  return Array.isArray(notifications)
    ? notifications
    : [];
}

export function saveNotifications(notifications) {
  if (!Array.isArray(notifications)) {
    return false;
  }

  return writeStorage(
    STORAGE_KEYS.NOTIFICATIONS,
    notifications
  );
}

export function addNotification(notification) {
  if (
    !notification ||
    typeof notification !== "object" ||
    !notification.recipientEmail
  ) {
    return false;
  }

  const notifications = getNotifications();

  const newNotification = {
    ...notification,
    id: `notification_${Date.now()}_${Math.random()
      .toString(36)
      .slice(2, 8)}`,
    read: false,
    createdAt: new Date().toISOString(),
  };

  return saveNotifications([
    newNotification,
    ...notifications,
  ]);
}
