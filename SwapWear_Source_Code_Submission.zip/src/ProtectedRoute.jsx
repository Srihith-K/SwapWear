
import { Navigate, useLocation } from "react-router-dom";
import { getCurrentUser } from "./utils/storage";

function ProtectedRoute({ children }) {
  const location = useLocation();
  const currentUser = getCurrentUser();

  if (!currentUser || !currentUser.email) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: location.pathname }}
      />
    );
  }

  return children;
}

export default ProtectedRoute;
