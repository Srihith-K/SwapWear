import { Link } from "react-router-dom";
import "../App.css";

function Home() {
  const categories = [
    {
      name: "Men's Clothing",
      count: "250+ items",
      icon: "👕",
      className: "green-card",
    },
    {
      name: "Women's Clothing",
      count: "420+ items",
      icon: "👗",
      className: "lavender-card",
    },
    {
      name: "Jackets",
      count: "120+ items",
      icon: "🧥",
      className: "peach-card",
    },
    {
      name: "Footwear",
      count: "180+ items",
      icon: "👟",
      className: "cream-card",
    },
  ];

  const items = [
    {
      category: "MEN'S · TOPS",
      title: "Classic Cotton T-Shirt",
      details: "Size M  ·  Casual",
      condition: "Good condition",
      icon: "👕",
      className: "item-green",
    },
    {
      category: "UNISEX · OUTERWEAR",
      title: "Everyday Denim Jacket",
      details: "Size L  ·  Casual",
      condition: "Like new",
      icon: "🧥",
      className: "item-blue",
    },
    {
      category: "WOMEN'S · DRESSES",
      title: "Floral Summer Dress",
      details: "Size S  ·  Summer",
      condition: "Good condition",
      icon: "👗",
      className: "item-pink",
    },
  ];

  const steps = [
    {
      number: "01",
      icon: "+",
      title: "List Your Clothes",
      description:
        "Upload photos and details of clothes you no longer wear.",
    },
    {
      number: "02",
      icon: "⌕",
      title: "Discover Items",
      description:
        "Browse clothes from people nearby and find something you like.",
    },
    {
      number: "03",
      icon: "↔",
      title: "Request a Swap",
      description:
        "Send a swap request and connect with the clothing owner.",
    },
    {
      number: "04",
      icon: "✓",
      title: "Make the Exchange",
      description:
        "Agree on the exchange and give your clothes a new life.",
    },
  ];

  return (
    <div className="app">

      {/* ================= NAVBAR ================= */}
      <header className="navbar">
        <div className="navbar-inner">

          <Link to="/" className="logo">
            <span className="logo-icon">♻</span>
            <span>SwapWear</span>
          </Link>

          <nav className="nav-links">
            <Link to="/" className="active">
              Home
            </Link>

            <Link to="/browse">
              Browse
            </Link>

            <a href="#how-it-works">
              How It Works
            </a>

            <a href="#about">
              About
            </a>
          </nav>

          <div className="nav-actions">
            <Link to="/login" className="login-link">
              Login
            </Link>

            <Link to="/register" className="register-link">
              Register
            </Link>

            <Link to="/list-clothing" className="nav-cta">
              + List Clothing
            </Link>
          </div>

        </div>
      </header>


      {/* ================= HERO ================= */}
      <main>

        <section className="hero-section">

          <div className="hero-inner">

            {/* LEFT */}
            <div className="hero-content">

              <div className="hero-badge">
                <span className="badge-symbol">♻</span>
                Sustainable Fashion
              </div>

              <h1>
                Give Your
                <br />
                Clothes
                <br />
                <span>A Second Life.</span>
              </h1>

              <p className="hero-description">
                Swap clothes with people in your community.
                Refresh your wardrobe while helping reduce
                textile waste.
              </p>

              <div className="hero-actions">

                <Link to="/browse" className="primary-button">
                  Browse Clothes
                  <span>→</span>
                </Link>

                <Link to="/list-clothing" className="secondary-button">
                  List Your Clothes
                  <span>→</span>
                </Link>

              </div>

              <div className="hero-community">

                <div className="avatar-stack">
                  <span>👤</span>
                  <span>👤</span>
                  <span>👤</span>
                </div>

                <div>
                  <strong>500+ people</strong>
                  <small>already swapping sustainably</small>
                </div>

              </div>

            </div>


            {/* RIGHT */}
            <div className="hero-visual">

              <div className="hero-art">

                <div className="art-top-label">
                  <span className="small-icon">♻</span>

                  <div>
                    <strong>Sustainable choice</strong>
                  </div>
                </div>

                <div className="eco-glow glow-one"></div>
                <div className="eco-glow glow-two"></div>

                <div className="hero-clothing">
                  👕
                </div>

                <div className="eco-card">

                  <span className="eco-card-label">
                    PRE-LOVED
                  </span>

                  <strong>
                    Give it another life.
                  </strong>

                  <span className="eco-arrow">
                    ↔
                  </span>

                </div>

                <div className="floating-eco-card">

                  <div className="floating-icon">
                    ↔
                  </div>

                  <div>
                    <strong>Easy Swaps</strong>
                    <small>Find your next favorite</small>
                  </div>

                </div>

                <div className="floating-left-card">

                  <div className="floating-icon green">
                    ♻
                  </div>

                  <div>
                    <strong>Eco Friendly</strong>
                    <small>Less textile waste</small>
                  </div>

                </div>

              </div>

            </div>

          </div>

        </section>


        {/* ================= STATS ================= */}
        <section className="stats-section">

          <div className="stats-inner">

            <div className="stat">
              <strong>1,200+</strong>
              <span>Clothing Items</span>
            </div>

            <div className="stat-divider"></div>

            <div className="stat">
              <strong>850+</strong>
              <span>Successful Swaps</span>
            </div>

            <div className="stat-divider"></div>

            <div className="stat">
              <strong>500+</strong>
              <span>Active Users</span>
            </div>

            <div className="stat-divider"></div>

            <div className="stat">
              <strong>100%</strong>
              <span>Community Driven</span>
            </div>

          </div>

        </section>


        {/* ================= CATEGORIES ================= */}
        <section className="categories-section" id="browse">

          <div className="section-container">

            <div className="section-header">

              <div>
                <span className="section-label">
                  EXPLORE
                </span>

                <h2>
                  Find Something You'll Love
                </h2>

                <p>
                  Browse clothing available for swapping in
                  your community.
                </p>
              </div>

              <Link to="/browse" className="section-link">
                View all clothes →
              </Link>

            </div>


            <div className="category-grid">

              {categories.map((category) => (
                <Link
                  to="/browse"
                  className={`category-card ${category.className}`}
                  key={category.name}
                >

                  <div className="category-image">
                    <span>{category.icon}</span>
                  </div>

                  <div className="category-content">

                    <div>
                      <h3>{category.name}</h3>
                      <p>{category.count}</p>
                    </div>

                    <span className="category-arrow">
                      →
                    </span>

                  </div>

                </Link>
              ))}

            </div>

          </div>

        </section>


        {/* ================= FRESH FINDS ================= */}
        <section className="fresh-section">

          <div className="section-container">

            <div className="section-header">

              <div>
                <span className="section-label">
                  COMMUNITY PICKS
                </span>

                <h2>
                  Fresh Finds
                </h2>

                <p>
                  Discover pre-loved pieces ready for their
                  next chapter.
                </p>
              </div>

              <Link to="/browse" className="section-link">
                Browse everything →
              </Link>

            </div>


            <div className="items-grid">

              {items.map((item) => (
                <div
                  className="clothing-item"
                  key={item.title}
                >

                  <div className={`item-image ${item.className}`}>

                    <span className="condition">
                      {item.condition}
                    </span>

                    <span className="item-emoji">
                      {item.icon}
                    </span>

                  </div>

                  <div className="item-details">

                    <span className="item-category">
                      {item.category}
                    </span>

                    <h3>
                      {item.title}
                    </h3>

                    <p>
                      {item.details}
                    </p>

                    <div className="item-bottom">

                      <span>
                        Open to swap
                      </span>

                      <Link to="/browse">
                        View →
                      </Link>

                    </div>

                  </div>

                </div>
              ))}

            </div>

          </div>

        </section>


        {/* ================= HOW IT WORKS ================= */}
        <section
          className="how-section"
          id="how-it-works"
        >

          <div className="section-container">

            <div className="center-heading">

              <span className="section-label">
                HOW IT WORKS
              </span>

              <h2>
                Swap. Refresh. Repeat.
              </h2>

              <p>
                Exchanging clothes has never been easier.
              </p>

            </div>


            <div className="steps-grid">

              {steps.map((step) => (
                <div className="step-card" key={step.number}>

                  <span className="step-number">
                    {step.number}
                  </span>

                  <div className="step-icon">
                    {step.icon}
                  </div>

                  <h3>
                    {step.title}
                  </h3>

                  <p>
                    {step.description}
                  </p>

                </div>
              ))}

            </div>

          </div>

        </section>


        {/* ================= WHY SWAPWEAR ================= */}
        <section className="why-section">

          <div className="section-container why-inner">

            <div className="why-content">

              <span className="section-label">
                WHY SWAPWEAR?
              </span>

              <h2>
                Fashion should feel
                <br />
                good in every way.
              </h2>

              <p>
                SwapWear makes it easier to keep clothes
                in use for longer while connecting you with
                people in your community.
              </p>

              <Link to="/browse" className="text-button">
                Start swapping →
              </Link>

            </div>


            <div className="benefits-grid">

              <div className="benefit-card">

                <div className="benefit-icon">
                  ♻
                </div>

                <h3>
                  Sustainable
                </h3>

                <p>
                  Help reduce textile waste by keeping
                  clothes in circulation.
                </p>

              </div>


              <div className="benefit-card">

                <div className="benefit-icon">
                  ♡
                </div>

                <h3>
                  Community
                </h3>

                <p>
                  Connect with people and exchange items
                  within your community.
                </p>

              </div>


              <div className="benefit-card">

                <div className="benefit-icon">
                  ↔
                </div>

                <h3>
                  Simple
                </h3>

                <p>
                  Discover, request and exchange clothes
                  without unnecessary complexity.
                </p>

              </div>


              <div className="benefit-card">

                <div className="benefit-icon">
                  ✦
                </div>

                <h3>
                  Affordable
                </h3>

                <p>
                  Refresh your wardrobe without constantly
                  buying something new.
                </p>

              </div>

            </div>

          </div>

        </section>


        {/* ================= CTA ================= */}
        <section className="cta-section">

          <div className="cta-container">

            <span className="section-label light">
              READY TO START?
            </span>

            <h2>
              Your unused clothes could be
              <br />
              someone's favorite.
            </h2>

            <p>
              Give them a second life with SwapWear.
            </p>

            <div className="cta-buttons">

              <Link
                to="/browse"
                className="cta-primary"
              >
                Start Browsing →
              </Link>

              <Link
                to="/list-clothing"
                className="cta-secondary"
              >
                List an Item
              </Link>

            </div>

          </div>

        </section>

      </main>


      {/* ================= FOOTER ================= */}
      <footer id="about" className="footer">

        <div className="footer-inner">

          <div className="footer-brand">

            <Link to="/" className="footer-logo">

              <span className="footer-logo-icon">
                ♻
              </span>

              SwapWear

            </Link>

            <p>
              Making fashion more sustainable,
              one swap at a time.
            </p>

          </div>


          <div className="footer-column">

            <h4>Explore</h4>

            <Link to="/browse">
              Browse Clothes
            </Link>

            <Link to="/list-clothing">
              List Clothing
            </Link>

            <a href="#how-it-works">
              How It Works
            </a>

          </div>


          <div className="footer-column">

            <h4>Account</h4>

            <Link to="/login">
              Login
            </Link>

            <Link to="/register">
              Register
            </Link>

            <Link to="/dashboard">
              Dashboard
            </Link>

          </div>


          <div className="footer-column">

            <h4>Information</h4>

            <a href="#about">
              About SwapWear
            </a>

            <a href="#about">
              Privacy
            </a>

            <a href="#about">
              Terms
            </a>

          </div>

        </div>


        <div className="footer-bottom">
          © 2026 SwapWear. Sustainable fashion starts with us.
        </div>

      </footer>

    </div>
  );
}

export default Home;