import { useMemo, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  getCurrentUser,
  getSwapRequests,
  getMessages,
  saveMessages,
  normalizeEmail,
  addNotification,
} from "../utils/storage";
import "./Chat.css";

function Chat() {
  const [currentUser] = useState(() => getCurrentUser());
  const [requests] = useState(() => getSwapRequests());
  const [messages, setMessages] = useState(() => getMessages());
  const [selectedConversationId, setSelectedConversationId] = useState(null);
  const [messageText, setMessageText] = useState("");
  const [searchParams] = useSearchParams();
  const requestedItemId = searchParams.get("itemId");


const currentEmail = normalizeEmail(currentUser?.email || "");
const currentId = currentUser?.id || currentEmail;

  // Create conversations from swap requests involving current user
const conversations = useMemo(() => {
  if (!currentUser) return [];

  return requests
    .map((request) => {
      const requesterEmail = normalizeEmail(request.requesterEmail || "");
      const ownerEmail = normalizeEmail(request.ownerEmail || "");

      const isRequester =
        request.requesterId === currentId ||
        (currentEmail && requesterEmail === currentEmail);

      const isOwner =
        request.ownerId === currentId ||
        (currentEmail && ownerEmail === currentEmail);

      // A user should only see conversations involving them.
      if (isRequester === isOwner) return null;

      const otherId = isRequester
        ? request.ownerId || ownerEmail
        : request.requesterId || requesterEmail;

      const person = isRequester ? request.owner : request.requester;

      // Don't create a chat with a participant whose account is unknown.
      if (!otherId || !person) return null;

      const conversationId = `swap_${request.itemId}_${[
        String(currentId),
        String(otherId),
      ]
        .sort()
        .join("_")}`;

      // Supports displaying older messages that used name-based IDs.
      const legacyId = `${[
        currentUser.name,
        person,
      ]
        .sort()
        .join("_")}_${request.itemId}`;

      return {
        id: conversationId,
        legacyId,
        person,
        otherUserId: otherId,
        otherEmail: isRequester ? ownerEmail : requesterEmail,
        itemId: request.itemId,
        itemName: request.itemName,
        brand: request.brand,
        emoji: request.emoji,
        image: request.image,
        value: request.value,
        status: request.status,
        requestId: request.id,
      };
    })
    .filter(Boolean);
}, [requests, currentUser, currentId, currentEmail]);
// Derive the selected conversation from the URL or the user's selection.
const selectedConversation = useMemo(() => {
  if (conversations.length === 0) return null;
  if (selectedConversationId) {
    const manuallySelected = conversations.find(
      (conversation) => conversation.id === selectedConversationId
    );
    if (manuallySelected) return manuallySelected;
  }
  if (requestedItemId) {
    const matchingConversation = conversations.find(
      (conversation) => String(conversation.itemId) === String(requestedItemId)
    );
    if (matchingConversation) return matchingConversation;
  }
  return conversations[0];
}, [conversations, requestedItemId, selectedConversationId]);

// Messages for selected conversation
const conversationMessages = selectedConversation
  ? messages.filter(
      (message) =>
        message.conversationId === selectedConversation.id ||
        message.conversationId === selectedConversation.legacyId
    )
  : [];

  // Send message
const handleSendMessage = (e) => {
  e.preventDefault();
    const text = messageText.trim();

  if (!text || !selectedConversation || !currentUser) return;

  const now = new Date();

  const newMessage = {
    id: `message_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    conversationId: selectedConversation.id,

    sender: currentUser.name,
    receiver: selectedConversation.person,

    senderId: currentId,
    receiverId: selectedConversation.otherUserId,

    senderEmail: currentEmail,
    receiverEmail: selectedConversation.otherEmail,

    text,
    timestamp: now.toISOString(),
    date: now.toLocaleDateString(),
    time: now.toLocaleTimeString([], {
      hour: "2-digit",
      minute: "2-digit",
    }),
  };

const updatedMessages = [...messages, newMessage];

const saved = saveMessages(updatedMessages);

if (!saved) {
  alert("Unable to send message. Please try again.");
  return;
}

// Notify the message recipient
if (selectedConversation.otherEmail) {
  addNotification({
    recipientEmail: selectedConversation.otherEmail,
    type: "new_message",
    title: "New Message",
    message: `${currentUser.name || "A member"} sent you a message.`,
    relatedId: selectedConversation.itemId,
    link: `/chat?itemId=${encodeURIComponent(
      selectedConversation.itemId
    )}`,
  });
}

setMessages(updatedMessages);
setMessageText("");

};

  // Logged-out state
  if (!currentUser) {
    return (
      <div className="chat-page">
        <header className="chat-navbar">
          <Link to="/" className="chat-logo">
            ♻️ SwapWear
          </Link>

          <nav className="chat-nav">
            <Link to="/">Home</Link>
            <Link to="/browse">Browse</Link>
            <Link to="/login">Login</Link>
          </nav>
        </header>

        <main className="chat-container">
          <div className="chat-empty-state">
            <div className="chat-empty-icon">💬</div>

            <h1>Messages</h1>

            <p>
              Please log in to view and send messages.
            </p>

            <Link to="/login" className="chat-primary-button">
              Login to Continue
            </Link>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="chat-page">
      {/* NAVBAR */}
      <header className="chat-navbar">
        <div className="chat-navbar-inner">
          <Link to="/" className="chat-logo">
            ♻️ SwapWear
          </Link>

          <nav className="chat-nav">
            <Link to="/">Home</Link>
            <Link to="/browse">Browse</Link>
            <Link to="/dashboard">Dashboard</Link>
            <Link to="/list-clothing">List Clothing</Link>
            <Link to="/swap-requests">
              Swap Requests
            </Link>
            <Link to="/chat" className="active">
              Messages
            </Link>
          </nav>
        </div>
      </header>

      {/* MAIN */}
      <main className="chat-container">
        <div className="chat-heading">
          <div>
            <small>MESSAGES</small>

            <h1>Chat with Swap Members</h1>

            <p>
              Discuss your clothing swaps and coordinate
              with other members.
            </p>
          </div>

          <Link
            to="/swap-requests"
            className="chat-secondary-button"
          >
            ← Swap Requests
          </Link>
        </div>

        {conversations.length === 0 ? (
          <div className="chat-empty-state">
            <div className="chat-empty-icon">💬</div>

            <h2>No conversations yet</h2>

            <p>
              Request a clothing swap to start a
              conversation with another member.
            </p>

            <Link
              to="/browse"
              className="chat-primary-button"
            >
              Browse Clothes →
            </Link>
          </div>
        ) : (
          <section className="chat-layout">
            {/* CONVERSATION LIST */}
            <aside className="conversation-sidebar">
              <div className="conversation-sidebar-header">
                <h2>Conversations</h2>

                <span>
                  {conversations.length}
                </span>
              </div>

              <div className="conversation-list">
                {conversations.map((conversation) => {
                  const isSelected =
                    selectedConversation?.id ===
                    conversation.id;

                  const latestMessage = messages
  .filter(
    (message) =>
      message.conversationId === conversation.id ||
      message.conversationId === conversation.legacyId
  )
  .sort(
    (a, b) =>
      new Date(b.timestamp).getTime() -
      new Date(a.timestamp).getTime()
  )[0];
                  return (
                    <button
                      key={conversation.id}
                      className={`conversation-card ${
                        isSelected ? "selected" : ""
                      }`}
                      onClick={() =>
                        setSelectedConversationId(conversation.id)
                      }
                    >
                      <div className="conversation-avatar">
                        👤
                      </div>

                      <div className="conversation-info">
                        <div className="conversation-top">
                          <strong>
                            {conversation.person}
                          </strong>

                          {latestMessage && (
                            <span>
                              {latestMessage.time}
                            </span>
                          )}
                        </div>

                        <p>
                          {conversation.itemName}
                        </p>

                        <small>
                          {latestMessage
                            ? latestMessage.text
                            : "Start a conversation"}
                        </small>
                      </div>
                    </button>
                  );
                })}
              </div>
            </aside>

            {/* CHAT WINDOW */}
            <section className="chat-window">
              {selectedConversation && (
                <>
                  <header className="chat-window-header">
                    <div className="chat-person">
                      <div className="chat-person-avatar">
                        👤
                      </div>

                      <div>
                        <h2>
                          {selectedConversation.person}
                        </h2>

                        <p>
                          SwapWear Member
                        </p>
                      </div>
                    </div>

                    <div className="chat-item-summary">
                      <span>
                        {selectedConversation.emoji}
                      </span>

                      <div>
                        <strong>
                          {selectedConversation.itemName}
                        </strong>

                        <small>
                          {selectedConversation.brand}
                        </small>
                      </div>
                    </div>
                  </header>

                  {/* ITEM INFORMATION */}
                  <div className="chat-swap-info">
                    <div>
                      <span>Swap Item</span>
                      <strong>
                        {selectedConversation.itemName}
                      </strong>
                    </div>

                    <div>
                      <span>Value</span>
                      <strong>
                        ₹{selectedConversation.value}
                      </strong>
                    </div>

                    <div>
                      <span>Status</span>
                      <strong
                        className={`chat-status ${
  (selectedConversation.status || "Pending").toLowerCase()
}`}
                      >
                        {selectedConversation.status}
                      </strong>
                    </div>
                  </div>

                  {/* MESSAGES */}
                  <div className="messages-area">
                    {conversationMessages.length ===
                    0 ? (
                      <div className="no-messages">
                        <div>💬</div>

                        <h3>
                          Start the conversation
                        </h3>

                        <p>
                          Send a message to{" "}
                          {
                            selectedConversation.person
                          }{" "}
                          about this swap.
                        </p>
                      </div>
                    ) : (
                      conversationMessages.map(
                        (message) => {
                          const isMine = message.senderId
  ? message.senderId === currentId
  : message.sender === currentUser?.name;

                          return (
                            <div
                              key={message.id}
                              className={`message-row ${
                                isMine
                                  ? "mine"
                                  : "theirs"
                              }`}
                            >
                              <div className="message-bubble">
                                <p>
                                  {message.text}
                                </p>

                                <span>
                                  {message.time}
                                </span>
                              </div>
                            </div>
                          );
                        }
                      )
                    )}
                  </div>

                  {/* MESSAGE INPUT */}
                  <form
                    className="message-input-area"
                    onSubmit={handleSendMessage}
                  >
                    <input
                      type="text"
                      value={messageText}
                      onChange={(e) =>
                        setMessageText(e.target.value)
                      }
                      placeholder={`Message ${selectedConversation.person}...`}
                      maxLength={500}
                    />

                    <button
                      type="submit"
                      disabled={!messageText.trim()}
                    >
                      Send
                    </button>
                  </form>
                </>
              )}
            </section>
          </section>
        )}
      </main>
    </div>
  );
}

export default Chat;