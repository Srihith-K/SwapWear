
import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import {
  getCurrentUser,
  getUsers,
  saveUsers,
  setCurrentUser,
  normalizeEmail,
  getListings,
  saveListings,
  getSwapRequests,
  saveSwapRequests,
  getMessages,
  saveMessages,
} from "../utils/storage";

import "./Profile.css";

function Profile() {
  const navigate = useNavigate();

  const [currentUser, setCurrentUserState] = useState(() => getCurrentUser());
  const [name, setName] = useState(() => getCurrentUser()?.name || "");
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");

  // Redirect users who do not have an active session.
  useEffect(() => {
    if (!currentUser) navigate("/login");
  }, [currentUser, navigate]);

  // Save profile and synchronize marketplace records
  const handleSubmit = (e) => {
    e.preventDefault();

    const trimmedName = name.trim();

    if (!trimmedName) {
      setError("Please enter your name.");
      setMessage("");
      return;
    }

    if (!currentUser?.email) {
      setError("Unable to identify your account. Please log in again.");
      setMessage("");
      return;
    }

    setSaving(true);
    setError("");
    setMessage("");

    const currentEmail = normalizeEmail(currentUser.email);
    const currentId = currentUser.id || currentEmail;

    const updatedUser = {
      ...currentUser,
      name: trimmedName,
    };

    // 1. Update registered users
    const users = getUsers();

    const userIndex = users.findIndex(
      (user) =>
        (currentUser.id && user.id === currentUser.id) ||
        normalizeEmail(user.email || "") === currentEmail
    );

    const updatedUsers = [...users];

    if (userIndex >= 0) {
      updatedUsers[userIndex] = {
        ...updatedUsers[userIndex],
        ...updatedUser,
      };
    } else {
      updatedUsers.push(updatedUser);
    }

    // 2. Update the user's clothing listings
    const listings = getListings();

    const updatedListings = listings.map((listing) => {
      const isOwner =
        listing.ownerId === currentId ||
        normalizeEmail(listing.ownerEmail || "") === currentEmail;

      return isOwner
        ? {
            ...listing,
            ownerName: trimmedName,
          }
        : listing;
    });

    // 3. Update the user's swap requests
    const requests = getSwapRequests();

    const updatedRequests = requests.map((request) => {
      const isRequester =
        request.requesterId === currentId ||
        normalizeEmail(request.requesterEmail || "") === currentEmail;

      const isOwner =
        request.ownerId === currentId ||
        normalizeEmail(request.ownerEmail || "") === currentEmail;

      return {
        ...request,
        ...(isRequester ? { requester: trimmedName } : {}),
        ...(isOwner ? { owner: trimmedName } : {}),
      };
    });

    // 4. Update the user's chat message display names
    const messages = getMessages();

    const updatedMessages = messages.map((chatMessage) => {
      const isSender =
        chatMessage.senderId === currentId ||
        normalizeEmail(chatMessage.senderEmail || "") === currentEmail;

      const isReceiver =
        chatMessage.receiverId === currentId ||
        normalizeEmail(chatMessage.receiverEmail || "") === currentEmail;

      return {
        ...chatMessage,
        ...(isSender ? { sender: trimmedName } : {}),
        ...(isReceiver ? { receiver: trimmedName } : {}),
      };
    });

    // 5. Save all updated records
    const usersSaved = saveUsers(updatedUsers);
    const listingsSaved = saveListings(updatedListings);
    const requestsSaved = saveSwapRequests(updatedRequests);
    const messagesSaved = saveMessages(updatedMessages);

    // Update current login session
    const sessionSaved = usersSaved && setCurrentUser(updatedUser);

    if (
      !usersSaved ||
      !listingsSaved ||
      !requestsSaved ||
      !messagesSaved ||
      !sessionSaved
    ) {
      setError(
        "Some information could not be saved. Please check your storage and try again."
      );

      setSaving(false);
      return;
    }

    // Update React state
    setCurrentUserState(updatedUser);
    setName(trimmedName);

    setMessage(
      "Profile and marketplace details updated successfully!"
    );

    setSaving(false);
  };

  // Avoid displaying the page before loading the user
  if (!currentUser) {
    return null;
  }

  return (
    <div className="profile-page">

      {/* NAVBAR */}
      <header className="profile-navbar">

        <Link to="/" className="profile-logo">
          ♻️ SwapWear
        </Link>

        <nav className="profile-nav">
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/browse">Browse</Link>
          <Link to="/my-listings">My Listings</Link>
          <Link to="/chat">Messages</Link>
        </nav>

      </header>

      {/* MAIN CONTENT */}
      <main className="profile-container">

        <Link to="/dashboard" className="profile-back-link">
          ← Back to Dashboard
        </Link>

        <section className="profile-card">

          {/* PROFILE HEADER */}
          <div className="profile-heading">

            <div className="profile-avatar">
              👤
            </div>

            <h1>My Profile</h1>

            <p>
              Manage your SwapWear account information.
            </p>

          </div>

          {/* PROFILE FORM */}
          <form
            onSubmit={handleSubmit}
            className="profile-form"
          >

            <div className="profile-field">

              <label htmlFor="profile-name">
                Full Name
              </label>

              <input
                id="profile-name"
                type="text"
                value={name}
                onChange={(e) => {
                  setName(e.target.value);
                  setError("");
                  setMessage("");
                }}
                placeholder="Enter your name"
                maxLength={60}
                required
              />

            </div>

            <div className="profile-field">

              <label htmlFor="profile-email">
                Email Address
              </label>

              <input
                id="profile-email"
                type="email"
                value={currentUser.email || ""}
                readOnly
              />

              <small>
                Your registered email cannot be changed here.
              </small>

            </div>

            {/* ERROR MESSAGE */}
            {error && (
              <p className="profile-error">
                {error}
              </p>
            )}

            {/* SUCCESS MESSAGE */}
            {message && (
              <p className="profile-success">
                {message}
              </p>
            )}

            {/* SAVE BUTTON */}
            <button
              type="submit"
              className="profile-save-button"
              disabled={saving}
            >
              {saving ? "Saving..." : "Save Changes"}
            </button>

          </form>

        </section>

      </main>

    </div>
  );
}

export default Profile;
