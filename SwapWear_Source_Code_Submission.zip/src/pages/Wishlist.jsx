import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  getCurrentUser,
  getWishlist,
  saveWishlist,
  clearCurrentUser,
} from "../utils/storage";
import "./Wishlist.css";

function Wishlist() {
  const navigate = useNavigate()

  const [currentUser] = useState(() => getCurrentUser());
  const [wishlist, setWishlist] = useState(() =>
    currentUser?.email ? getWishlist(currentUser.email) : []
  );

  useEffect(() => {
    if (!currentUser?.email) navigate("/login");
  }, [currentUser, navigate]);

const removeFromWishlist = (itemId) => {
  if (!currentUser?.email) return;

  const updatedWishlist = wishlist.filter(
    (item) => String(item.id) !== String(itemId)
  );

  const saved = saveWishlist(currentUser.email, updatedWishlist);

  if (!saved) {
    alert("Unable to update your wishlist. Please try again.");
    return;
  }

  setWishlist(updatedWishlist);
};

  return (
    <div className="wishlist-page">

      {/* NAVBAR */}
      <nav className="wishlist-navbar">

        <Link to="/" className="wishlist-logo">
          SwapWear
        </Link>

        <div className="wishlist-nav">

          <Link to="/">
            Home
          </Link>

          <Link to="/browse">
            Browse
          </Link>

          <Link to="/list-clothing">
            List Clothing
          </Link>

          <Link to="/dashboard">
            Dashboard
          </Link>

          <Link
            to="/wishlist"
            className="active"
          >
            ❤️ Wishlist
          </Link>

          <Link
  to="/login"
  className="logout-link"
  onClick={() => clearCurrentUser()}
>
  Logout
</Link>

        </div>

      </nav>

      {/* MAIN */}
      <main className="wishlist-container">

        {/* HEADER */}
        <section className="wishlist-header">

          <div>

            <span className="wishlist-label">
              SAVED ITEMS
            </span>

            <h1>
              My Wishlist ❤️
            </h1>

            <p>
              Keep track of clothes you love and want to swap later.
            </p>

          </div>

          <Link
            to="/browse"
            className="browse-more-button"
          >
            ← Browse Clothes
          </Link>

        </section>

        {/* EMPTY STATE */}
        {wishlist.length === 0 ? (

          <section className="wishlist-empty">

            <div className="empty-heart">
              ♡
            </div>

            <h2>
              Your wishlist is empty
            </h2>

            <p>
              You haven't saved any clothes yet.
              Explore the marketplace and save items you like.
            </p>

            <Link
              to="/browse"
              className="empty-browse-button"
            >
              Browse Clothes
            </Link>

          </section>

        ) : (

          <>
            {/* SUMMARY */}
            <div className="wishlist-summary">

              <span>
                <strong>{wishlist.length}</strong>{" "}
                {wishlist.length === 1
                  ? "item saved"
                  : "items saved"}
              </span>

            </div>

            {/* GRID */}
            <section className="wishlist-grid">

              {wishlist.map((item) => (

                <article
                  className="wishlist-card"
                  key={item.id}
                >

                  {/* IMAGE */}
                  <div className="wishlist-image">

                    <span className="wishlist-emoji">
                      {item.emoji}
                    </span>

                    <span className="wishlist-condition">
                      {item.condition}
                    </span>

                    <button
                      type="button"
                      className="remove-wishlist-button"
                      onClick={() =>
                        removeFromWishlist(item.id)
                      }
                      title="Remove from wishlist"
                      aria-label="Remove from wishlist"
                    >
                      ♥
                    </button>

                  </div>

                  {/* INFO */}
                  <div className="wishlist-info">

                    <span className="wishlist-category">
                      {item.category}
                    </span>

                    <h2>
                      {item.name}
                    </h2>

                    <p className="wishlist-details">
                      {item.brand} • Size {item.size}
                    </p>

                    <p className="wishlist-location">
                      📍 {item.location}
                    </p>

                    {/* FOOTER */}
                    <div className="wishlist-card-footer">

                      <div className="wishlist-value">

                        <span>
                          Swap value
                        </span>

                        <strong>
                          ₹{item.value}
                        </strong>

                      </div>

                      <div className="wishlist-actions">

                        <Link
                          to={`/item/${item.id}`}
                          className="wishlist-view-button"
                        >
                          View
                        </Link>

                        <button
                          type="button"
                          className="wishlist-remove-button"
                          onClick={() =>
                            removeFromWishlist(item.id)
                          }
                        >
                          Remove
                        </button>

                      </div>

                    </div>

                  </div>

                </article>

              ))}

            </section>
          </>

        )}

      </main>

    </div>
  )
}

export default Wishlist