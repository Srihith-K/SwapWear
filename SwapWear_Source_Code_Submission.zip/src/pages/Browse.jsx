import { useMemo, useState } from "react";
import { Link } from "react-router-dom";
import {
  getListings,
  getCurrentUser,
  getWishlist,
  saveWishlist,
} from "../utils/storage";
import "./Browse.css";

const clothingItems = [
  {
    id: 1,
    name: "Classic Cotton T-Shirt",
    brand: "H&M",
    category: "T-Shirts",
    size: "M",
    condition: "Good",
    location: "Hyderabad",
    value: 500,
    emoji: "👕",
    tone: "green",
  },
  {
    id: 2,
    name: "Everyday Denim Jacket",
    brand: "Levi's",
    category: "Jackets",
    size: "L",
    condition: "Like New",
    location: "Bangalore",
    value: 1200,
    emoji: "🧥",
    tone: "blue",
  },
  {
    id: 3,
    name: "Floral Summer Dress",
    brand: "Zara",
    category: "Dresses",
    size: "S",
    condition: "Good",
    location: "Chennai",
    value: 1500,
    emoji: "👗",
    tone: "rose",
  },
  {
    id: 4,
    name: "Classic Running Shoes",
    brand: "Nike",
    category: "Footwear",
    size: "9",
    condition: "Excellent",
    location: "Mumbai",
    value: 1800,
    emoji: "👟",
    tone: "sand",
  },
  {
    id: 5,
    name: "Relaxed Oxford Shirt",
    brand: "Uniqlo",
    category: "Shirts",
    size: "M",
    condition: "Excellent",
    location: "Pune",
    value: 900,
    emoji: "👔",
    tone: "cream",
  },
  {
    id: 6,
    name: "Slim Fit Denim Jeans",
    brand: "Levi's",
    category: "Jeans",
    size: "32",
    condition: "Excellent",
    location: "Bangalore",
    value: 1200,
    emoji: "👖",
    tone: "denim",
  },
  {
    id: 7,
    name: "Cotton Casual Shirt",
    brand: "Uniqlo",
    category: "Shirts",
    size: "M",
    condition: "Like New",
    location: "Pune",
    value: 700,
    emoji: "👔",
    tone: "lavender",
  },
  {
    id: 8,
    name: "Graphic Print T-Shirt",
    brand: "Puma",
    category: "T-Shirts",
    size: "L",
    condition: "Good",
    location: "Delhi",
    value: 600,
    emoji: "👕",
    tone: "mint",
  },
];

const categories = [
  "All",
  "T-Shirts",
  "Shirts",
  "Jackets",
  "Dresses",
  "Jeans",
  "Footwear",
];

const sizes = ["All", "S", "M", "L", "9", "32"];

const conditions = ["All", "Like New", "Excellent", "Good"];

const locations = [
  "All",
  "Hyderabad",
  "Bangalore",
  "Chennai",
  "Mumbai",
  "Pune",
  "Delhi",
];

function SearchIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className="browse-icon"
    >
      <circle cx="11" cy="11" r="6.5" />
      <path d="M16 16L21 21" />
    </svg>
  );
}

function FilterIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className="browse-icon"
    >
      <path d="M4 6h16" />
      <path d="M7 12h10" />
      <path d="M10 18h4" />
    </svg>
  );
}

function MapPinIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className="small-icon"
    >
      <path d="M20 10.5c0 5-8 10-8 10s-8-5-8-10a8 8 0 1 1 16 0Z" />
      <circle cx="12" cy="10.5" r="2.5" />
    </svg>
  );
}

function HeartIcon() {
  return (
    <svg
      viewBox="0 0 24 24"
      aria-hidden="true"
      className="heart-icon"
    >
      <path d="M20.8 8.8c0 5.3-8.8 10.2-8.8 10.2S3.2 14.1 3.2 8.8A4.7 4.7 0 0 1 12 6.1a4.7 4.7 0 0 1 8.8 2.7Z" />
    </svg>
  );
}

function Browse() {
  const [search, setSearch] = useState("");
  const [category, setCategory] = useState("All");
  const [size, setSize] = useState("All");
  const [condition, setCondition] = useState("All");
  const [location, setLocation] = useState("All");
  const [sort, setSort] = useState("recommended");
  const [showFilters, setShowFilters] = useState(false);
  const [userListings] = useState(() =>
    getListings().filter((item) => item.status !== "Unavailable")
  );
  const availableLocations = [
  ...new Set([
    ...locations,
    ...userListings
      .map((item) => item.location?.trim())
      .filter(Boolean),
  ]),
];

const [currentUser] = useState(() => getCurrentUser());
const [favorites, setFavorites] = useState(() =>
  currentUser?.email ? getWishlist(currentUser.email) : []
);

  const filteredItems = useMemo(() => {
const allItems = [
  ...userListings,
  ...clothingItems,
].filter((item) => item.status !== "Unavailable");    
    const result = allItems.filter((item) => {
      const searchValue = search.toLowerCase().trim();

      const matchesSearch =
        !searchValue ||
        item.name.toLowerCase().includes(searchValue) ||
        item.brand.toLowerCase().includes(searchValue) ||
        item.category.toLowerCase().includes(searchValue);

      const matchesCategory =
        category === "All" || item.category === category;

      const matchesSize =
        size === "All" || item.size === size;

      const matchesCondition =
        condition === "All" || item.condition === condition;

      const matchesLocation =
        location === "All" || item.location === location;

      return (
        matchesSearch &&
        matchesCategory &&
        matchesSize &&
        matchesCondition &&
        matchesLocation
      );
    });

    if (sort === "low") {
      return [...result].sort((a, b) => a.value - b.value);
    }

    if (sort === "high") {
      return [...result].sort((a, b) => b.value - a.value);
    }

    if (sort === "newest") {
      return [...result].reverse();
    }

    return result;
  }, [userListings, search, category, size, condition, location, sort]);

const toggleFavorite = (item) => {
  if (!currentUser?.email) {
    alert("Please login to add items to your wishlist.");
    return;
  }

  const alreadyFavorite = favorites.some(
    (favoriteItem) => String(favoriteItem.id) === String(item.id)
  );

  const updatedFavorites = alreadyFavorite
    ? favorites.filter(
        (favoriteItem) => String(favoriteItem.id) !== String(item.id)
      )
    : [
        ...favorites,
        {
          id: item.id,
          name: item.name,
          brand: item.brand,
          category: item.category,
          size: item.size,
          condition: item.condition,
          location: item.location,
          value: item.value,
          emoji: item.emoji,
          tone: item.tone,
          image: item.image || "",
        },
      ];

  const saved = saveWishlist(currentUser.email, updatedFavorites);

  if (!saved) {
    alert("Unable to update your wishlist. Please try again.");
    return;
  }

  setFavorites(updatedFavorites);
};

const isFavorite = (id) => {
  return favorites.some(
    (favoriteItem) => favoriteItem.id === id
  );
};


  const clearFilters = () => {
    setSearch("");
    setCategory("All");
    setSize("All");
    setCondition("All");
    setLocation("All");
    setSort("recommended");
  };

  return (
    <div className="browse-page">

      {/* NAVBAR */}
      <header className="browse-navbar">
        <div className="browse-nav-inner">
          <Link to="/" className="browse-logo">
            <span className="logo-mark">♻</span>
            <span>SwapWear</span>
          </Link>
          <Link to="/swap-calculator">
  Swap Calculator
</Link>

          <nav className="browse-main-nav">
            <Link to="/">Home</Link>
            <Link to="/browse" className="active">
              Browse
            </Link>
            <a href="/#how-it-works">How It Works</a>
            <a href="/#about">About</a>
          </nav>

          <div className="browse-nav-actions">
            <Link to="/wishlist" className="nav-wishlist">
  ♡ Wishlist
  {favorites.length > 0 && (
    <span className="wishlist-nav-count">
      {favorites.length}
    </span>
  )}
</Link>
            <Link to="/login" className="nav-login">
              Login
            </Link>

            <Link to="/register" className="nav-register">
              Register
            </Link>

            <Link to="/list-clothing" className="nav-list-button">
              + List Clothing
            </Link>
          </div>
        </div>
      </header>

      {/* PAGE HEADER */}
      <main>
        <section className="browse-hero">
          <div className="browse-hero-inner">

            <div>
              <p className="eyebrow">SWAP MARKETPLACE</p>

              <h1>
                Find something
                <span> worth swapping.</span>
              </h1>

              <p className="hero-description">
                Discover pre-loved clothing from people in your
                community and give great pieces a second life.
              </p>
            </div>

            <div className="hero-count">
              <strong>1,200+</strong>
              <span>items in the community</span>
            </div>

          </div>
        </section>

        {/* SEARCH + FILTERS */}
        <section className="browse-controls-section">
          <div className="browse-container">

            <div className="search-row">

              <div className="search-box">
                <SearchIcon />

                <input
                  type="text"
                  placeholder="Search by item, brand or category..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />

                {search && (
                  <button
                    className="clear-search"
                    onClick={() => setSearch("")}
                    type="button"
                  >
                    ×
                  </button>
                )}
              </div>

              <button
                type="button"
                className="mobile-filter-button"
                onClick={() => setShowFilters(!showFilters)}
              >
                <FilterIcon />
                Filters
              </button>

              <div className="sort-wrapper">
                <label htmlFor="sort">Sort by</label>

                <select
                  id="sort"
                  value={sort}
                  onChange={(e) => setSort(e.target.value)}
                >
                  <option value="recommended">
                    Recommended
                  </option>
                  <option value="newest">
                    Newest
                  </option>
                  <option value="low">
                    Value: Low to High
                  </option>
                  <option value="high">
                    Value: High to Low
                  </option>
                </select>
              </div>

            </div>

            <div
              className={`filter-panel ${
                showFilters ? "filter-panel-open" : ""
              }`}
            >

              <div className="filter-title">
                <FilterIcon />
                <span>Filter by</span>
              </div>

              <div className="filter-group">
                <label>Category</label>

                <select
                  value={category}
                  onChange={(e) => setCategory(e.target.value)}
                >
                  {categories.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>

              <div className="filter-group">
                <label>Size</label>

                <select
                  value={size}
                  onChange={(e) => setSize(e.target.value)}
                >
                  {sizes.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>

              <div className="filter-group">
                <label>Condition</label>

                <select
                  value={condition}
                  onChange={(e) => setCondition(e.target.value)}
                >
                  {conditions.map((item) => (
                    <option key={item} value={item}>
                      {item}
                    </option>
                  ))}
                </select>
              </div>

<div className="filter-group">
  <label>Find Clothing by City</label>

  <select
    value={location}
    onChange={(e) => setLocation(e.target.value)}
  >
    {availableLocations.map((city) => (
      <option key={city} value={city}>
        {city === "All" ? "All Cities" : city}
      </option>
    ))}
  </select>
</div>

              <button
                type="button"
                className="clear-filters"
                onClick={clearFilters}
              >
                Clear filters
              </button>

            </div>
          </div>
        </section>

        {/* RESULTS */}
        <section className="browse-results">
          <div className="browse-container">

            <div className="results-heading">

              <div>
                <p className="eyebrow">COMMUNITY CLOSET</p>

                <h2>
                  {filteredItems.length}{" "}
                  {filteredItems.length === 1
                    ? "piece"
                    : "pieces"}{" "}
                  available
                </h2>
                {location !== "All" && (
  <p className="nearby-match-label">
    📍 Showing clothing exchange opportunities in {location}
  </p>
)}

{location === "All" && (
  <p className="nearby-match-label">
    🌍 Browse clothing exchange opportunities across all cities.
  </p>
)}
              </div>

              <p className="results-note">
                Every item is ready for a new chapter.
              </p>

            </div>

            {filteredItems.length > 0 ? (
              <div className="clothing-grid">

                {filteredItems.map((item) => (
                  <article
                    className="clothing-card"
                    key={item.id}
                  >

                    <div
                      className={`clothing-image ${item.tone}`}
                    >
                      <span
                        className={`condition-badge ${
                          item.condition
                            .toLowerCase()
                            .replace(/\s/g, "-")
                        }`}
                      >
                        {item.condition}
                      </span>

                      <button
                        type="button"
                        className={`favorite-button ${
                          isFavorite(item.id)
                            ? "favorited"
                            : ""
                        }`}
                        onClick={() =>
                          toggleFavorite(item)
                        }
                        aria-label={`${
                          isFavorite(item.id)
                            ? "Remove"
                            : "Add"
                        } ${item.name} ${
                          isFavorite(item.id)
                            ? "from"
                            : "to"
                        } favorites`}
                      >
                        <HeartIcon />
                      </button>

                      {item.image ? (
  <img
    src={item.image}
    alt={item.name}
    className="user-listing-image"
  />
) : (
  <div className="clothing-emoji">
    {item.emoji || "👕"}
  </div>
)}
                    </div>

                    <div className="clothing-content">

                      <div className="item-category">
                        {item.category} · {item.brand}
                      </div>

                      <h3>{item.name}</h3>

                      <div className="item-meta">
                        <span>Size {item.size}</span>
                        <span className="meta-dot">•</span>
                        <span>{item.condition}</span>
                      </div>

                      <div className="item-location">
                        <MapPinIcon />
                        <span>{item.location}</span>
                      </div>

                      <div className="card-divider" />

                      <div className="card-bottom">

                        <div>
                          <span className="value-label">
                            Swap value
                          </span>

                          <strong>
                            ₹{item.value.toLocaleString("en-IN")}
                          </strong>
                        </div>

                        <Link
                          to={`/item/${item.id}`}
                          className="view-button"
                        >
                          View Details
                          <span>→</span>
                        </Link>

                      </div>

                    </div>

                  </article>
                ))}

              </div>
            ) : (
              <div className="empty-state">

                <div className="empty-icon">
                  <SearchIcon />
                </div>

                <h3>No clothing found</h3>

                <p>
                  We couldn't find anything matching your
                  current filters.
                </p>

                <button
                  type="button"
                  onClick={clearFilters}
                >
                  Reset filters
                </button>

              </div>
            )}

          </div>
        </section>

        {/* BOTTOM CTA */}
        <section className="browse-cta">
          <div className="browse-cta-inner">

            <div>
              <p className="eyebrow">HAVE CLOTHES TO SHARE?</p>

              <h2>
                Someone might be looking
                <br />
                for exactly what you have.
              </h2>

              <p>
                List your pre-loved clothes and give them
                another life.
              </p>
            </div>

            <Link
              to="/list-clothing"
              className="cta-button"
            >
              List Your Clothes
              <span>→</span>
            </Link>

          </div>
        </section>

      </main>

      {/* FOOTER */}
      <footer className="browse-footer" id="about">

        <div className="browse-footer-inner">

          <div className="footer-brand">
            <Link to="/" className="footer-logo">
              <span className="logo-mark">♻</span>
              SwapWear
            </Link>

            <p>
              Making fashion more sustainable,
              one swap at a time.
            </p>
          </div>

          <div className="footer-column">
            <h4>Explore</h4>
            <Link to="/browse">Browse Clothes</Link>
            <Link to="/list-clothing">List Clothing</Link>
            <a href="/#how-it-works">How It Works</a>
          </div>

          <div className="footer-column">
            <h4>Account</h4>
            <Link to="/login">Login</Link>
            <Link to="/register">Register</Link>
            <Link to="/dashboard">Dashboard</Link>
          </div>

          <div className="footer-column">
            <h4>Information</h4>
            <a href="/#about">About SwapWear</a>
            <a href="#">Privacy</a>
            <a href="#">Terms</a>
          </div>

        </div>

        <div className="footer-bottom">
          © 2026 SwapWear. Sustainable fashion starts with us.
        </div>

      </footer>

    </div>
  );
}

export default Browse;