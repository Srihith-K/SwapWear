
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";

import {
  getCurrentUser,
  getUsers,
  saveUsers,
  getListings,
  saveListings,
  getSwapRequests,
  saveSwapRequests,
  getMessages,
  saveMessages,
  normalizeEmail,
  clearCurrentUser,
} from "../utils/storage";

import "./Admin.css";

// Change this to the email you will use for your admin account.
const ADMIN_EMAIL = "srihith.kv@gmail.com";

function Admin() {
  const navigate = useNavigate();

  const currentUser = getCurrentUser();

  const isAdmin =
    normalizeEmail(currentUser?.email || "") ===
    normalizeEmail(ADMIN_EMAIL);

  const [users, setUsers] = useState(() => getUsers());
  const [listings, setListings] = useState(() => getListings());
  const [requests, setRequests] = useState(() => getSwapRequests());
  const [activeTab, setActiveTab] = useState("overview");

  if (!currentUser) {
    navigate("/login", { replace: true });
    return null;
  }

  if (!isAdmin) {
    return (
      <div className="admin-access-denied">
        <h1>Access Denied</h1>
        <p>You don't have permission to access the Admin Dashboard.</p>
        <Link to="/dashboard">Return to Dashboard</Link>
      </div>
    );
  }

  const pendingRequests = requests.filter(
    (request) => request.status === "Pending"
  ).length;

  const completedRequests = requests.filter(
    (request) => request.status === "Completed"
  ).length;

  const acceptedRequests = requests.filter(
    (request) => request.status === "Accepted"
  ).length;

  const handleDeleteListing = (listingId) => {
    const confirmed = window.confirm(
      "Are you sure you want to remove this listing?"
    );

    if (!confirmed) return;

    const updated = listings.filter(
      (item) => String(item.id) !== String(listingId)
    );

    if (!saveListings(updated)) {
      alert("Unable to remove listing.");
      return;
    }

    setListings(updated);
  };

  const handleDeleteUser = (user) => {
    if (
      normalizeEmail(user.email) ===
      normalizeEmail(ADMIN_EMAIL)
    ) {
      alert("You cannot delete the admin account.");
      return;
    }

    const confirmed = window.confirm(
      `Delete ${user.name}'s account and associated marketplace data?`
    );

    if (!confirmed) return;

    const email = normalizeEmail(user.email);
    const userId = user.id;

    const updatedUsers = users.filter(
      (item) =>
        normalizeEmail(item.email) !== email
    );

    const updatedListings = listings.filter(
      (item) =>
        item.ownerId !== userId &&
        normalizeEmail(item.ownerEmail || "") !== email
    );

    const updatedRequests = requests.filter(
      (item) =>
        item.requesterId !== userId &&
        item.ownerId !== userId &&
        normalizeEmail(item.requesterEmail || "") !== email &&
        normalizeEmail(item.ownerEmail || "") !== email
    );

    const updatedMessages = getMessages().filter(
      (message) =>
        message.senderId !== userId &&
        message.receiverId !== userId &&
        normalizeEmail(message.senderEmail || "") !== email &&
        normalizeEmail(message.receiverEmail || "") !== email
    );

    const success =
      saveUsers(updatedUsers) &&
      saveListings(updatedListings) &&
      saveSwapRequests(updatedRequests) &&
      saveMessages(updatedMessages);

    if (!success) {
      alert(
        "Some data could not be saved. Please check Local Storage."
      );
      return;
    }

    localStorage.removeItem(`swapwear_wishlist_${email}`);

    setUsers(updatedUsers);
    setListings(updatedListings);
    setRequests(updatedRequests);

    alert("User and associated data removed.");
  };

  const handleLogout = () => {
    clearCurrentUser();
    navigate("/login", { replace: true });
  };

  return (
    <div className="admin-page">
      <header className="admin-navbar">
        <Link to="/" className="admin-logo">
          ♻️ SwapWear Admin
        </Link>

        <nav>
          <Link to="/dashboard">User Dashboard</Link>
          <button onClick={handleLogout}>Logout</button>
        </nav>
      </header>

      <main className="admin-container">
        <section className="admin-heading">
          <div>
            <span>ADMINISTRATION</span>
            <h1>Admin Dashboard</h1>
            <p>Manage your SwapWear marketplace.</p>
          </div>
        </section>

        <section className="admin-stats">
          <div className="admin-stat-card">
            <span>👥</span>
            <h2>{users.length}</h2>
            <p>Total Users</p>
          </div>

          <div className="admin-stat-card">
            <span>👕</span>
            <h2>{listings.length}</h2>
            <p>Total Listings</p>
          </div>

          <div className="admin-stat-card">
            <span>⏳</span>
            <h2>{pendingRequests}</h2>
            <p>Pending Requests</p>
          </div>

          <div className="admin-stat-card">
            <span>✓</span>
            <h2>{completedRequests}</h2>
            <p>Completed Swaps</p>
          </div>
        </section>

        <section className="admin-overview">
          <div className="admin-summary-card">
            <h3>Swap Activity</h3>
            <p>Accepted: <strong>{acceptedRequests}</strong></p>
            <p>Completed: <strong>{completedRequests}</strong></p>
            <p>Pending: <strong>{pendingRequests}</strong></p>
            <p>Total: <strong>{requests.length}</strong></p>
          </div>

          <div className="admin-summary-card">
            <h3>Marketplace Overview</h3>
            <p>Registered users: <strong>{users.length}</strong></p>
            <p>Clothing listings: <strong>{listings.length}</strong></p>
            <p>Swap requests: <strong>{requests.length}</strong></p>
          </div>
        </section>

        <div className="admin-tabs">
          <button
            className={activeTab === "overview" ? "active" : ""}
            onClick={() => setActiveTab("overview")}
          >
            Overview
          </button>

          <button
            className={activeTab === "users" ? "active" : ""}
            onClick={() => setActiveTab("users")}
          >
            Users ({users.length})
          </button>

          <button
            className={activeTab === "listings" ? "active" : ""}
            onClick={() => setActiveTab("listings")}
          >
            Listings ({listings.length})
          </button>

          <button
            className={activeTab === "requests" ? "active" : ""}
            onClick={() => setActiveTab("requests")}
          >
            Swap Requests ({requests.length})
          </button>
        </div>

        {activeTab === "overview" && (
          <section className="admin-table-section">
            <h2>Recent Swap Activity</h2>

            {requests.length === 0 ? (
              <p>No swap activity available.</p>
            ) : (
              <div className="admin-table-wrapper">
                <table className="admin-table">
                  <thead>
                    <tr>
                      <th>Item</th>
                      <th>Requester</th>
                      <th>Owner</th>
                      <th>Status</th>
                    </tr>
                  </thead>

                  <tbody>
                    {requests.slice().reverse().slice(0, 10).map((request) => (
                      <tr key={request.id}>
                        <td>{request.itemName || "Clothing"}</td>
                        <td>{request.requester || "Member"}</td>
                        <td>{request.owner || "Member"}</td>
                        <td>{request.status || "Pending"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </section>
        )}

        {activeTab === "users" && (
          <section className="admin-table-section">
            <h2>User Management</h2>

            <div className="admin-table-wrapper">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {users.map((user) => (
                    <tr key={user.id || user.email}>
                      <td>{user.name}</td>
                      <td>{user.email}</td>
                      <td>
                        {normalizeEmail(user.email) ===
                        normalizeEmail(ADMIN_EMAIL) ? (
                          <span>Admin</span>
                        ) : (
                          <button
                            className="admin-delete-button"
                            onClick={() => handleDeleteUser(user)}
                          >
                            Delete
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {activeTab === "listings" && (
          <section className="admin-table-section">
            <h2>Clothing Listing Management</h2>

            <div className="admin-table-wrapper">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Item</th>
                    <th>Brand</th>
                    <th>Owner</th>
                    <th>Value</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>

                <tbody>
                  {listings.map((item) => (
                    <tr key={item.id}>
                      <td>{item.name}</td>
                      <td>{item.brand || "-"}</td>
                      <td>{item.ownerName || "Member"}</td>
                      <td>₹{item.value || 0}</td>
                      <td>{item.status || "Available"}</td>
                      <td>
                        <button
                          className="admin-delete-button"
                          onClick={() => handleDeleteListing(item.id)}
                        >
                          Remove
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}

        {activeTab === "requests" && (
          <section className="admin-table-section">
            <h2>Swap Request Monitoring</h2>

            <div className="admin-table-wrapper">
              <table className="admin-table">
                <thead>
                  <tr>
                    <th>Item</th>
                    <th>Requester</th>
                    <th>Owner</th>
                    <th>Status</th>
                    <th>Date</th>
                  </tr>
                </thead>

                <tbody>
                  {requests.map((request) => (
                    <tr key={request.id}>
                      <td>{request.itemName || "Clothing"}</td>
                      <td>{request.requester || "Member"}</td>
                      <td>{request.owner || "Member"}</td>
                      <td>{request.status || "Pending"}</td>
                      <td>{request.date || "-"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </section>
        )}
      </main>
    </div>
  );
}

export default Admin;
