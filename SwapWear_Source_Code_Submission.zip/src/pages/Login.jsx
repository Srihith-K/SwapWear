
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useState } from "react";
import "./Auth.css";

import {
  getUsers,
  normalizeEmail,
  setCurrentUser,
} from "../utils/storage";

function Login() {
  const navigate = useNavigate();
  const location = useLocation();

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");

  const handleLogin = (e) => {
    e.preventDefault();
    setError("");

    const cleanEmail = normalizeEmail(email);
    const users = getUsers();

    if (users.length === 0) {
      setError("No account found. Please create an account first.");
      return;
    }

    const user = users.find(
      (savedUser) =>
        normalizeEmail(savedUser.email) === cleanEmail &&
        savedUser.password === password
    );

    if (!user) {
      setError("Invalid email or password.");
      return;
    }

    const sessionUser = {
      id: user.id,
      name: user.name,
      email: normalizeEmail(user.email),
    };

    const saved = setCurrentUser(sessionUser);

    if (!saved) {
      setError("Unable to save your session. Please try again.");
      return;
    }

    const destination = location.state?.from || "/dashboard";
    navigate(destination, { replace: true });
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-left">
          <div className="auth-logo">♻️ SwapWear</div>

          <h1>
            Welcome <span>Back.</span>
          </h1>

          <p>
            Continue your sustainable fashion journey.
            Discover clothes, connect with people, and
            give your wardrobe a second life.
          </p>

          <div className="auth-features">
            <div className="auth-feature">
              <div className="auth-feature-icon">✓</div>
              Easy clothing swaps
            </div>

            <div className="auth-feature">
              <div className="auth-feature-icon">✓</div>
              Sustainable fashion
            </div>

            <div className="auth-feature">
              <div className="auth-feature-icon">✓</div>
              Connect with your community
            </div>
          </div>
        </div>

        <div className="auth-right">
          <h2>Login</h2>

          <p className="auth-subtitle">
            Sign in to your SwapWear account
          </p>

          <form className="auth-form" onSubmit={handleLogin}>
            {error && (
              <div
                role="alert"
                style={{
                  padding: "12px 14px",
                  marginBottom: "16px",
                  borderRadius: "8px",
                  background: "#fff1f1",
                  color: "#c0392b",
                  fontSize: "14px",
                }}
              >
                {error}
              </div>
            )}

            <div className="auth-field">
              <label htmlFor="email">Email Address</label>

              <input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                required
              />
            </div>

            <div className="auth-field">
              <label htmlFor="password">Password</label>

              <input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="current-password"
                required
              />
            </div>

            <button type="submit" className="auth-button">
              Login
            </button>
          </form>

          <div className="auth-switch">
            Don't have an account?{" "}
            <Link to="/register">Create an account</Link>
          </div>

          <div className="auth-switch">
            <Link to="/">← Back to Home</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Login;
