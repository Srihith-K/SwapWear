import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import {
  getCurrentUser,
  getListings,
  getSwapRequests,
  clearCurrentUser,
  normalizeEmail,
} from "../utils/storage";
import "./Dashboard.css";

function Dashboard() {
  const navigate = useNavigate();
  const [currentUser] = useState(() => getCurrentUser());
  const [myListings] = useState(() => {
    const user = getCurrentUser();
    if (!user) return [];
    const email = normalizeEmail(user.email || "");
    const userId = user.id || email;
    return getListings().filter(
      (listing) =>
        listing.ownerId === userId ||
        normalizeEmail(listing.ownerEmail || "") === email
    );
  });
  const [swapRequests] = useState(() => getSwapRequests());

  useEffect(() => {
    if (!currentUser) navigate("/login");
  }, [currentUser, navigate]);

const currentEmail = normalizeEmail(currentUser?.email || "");
const currentId = currentUser?.id || currentEmail;

const mySwapRequests = swapRequests.filter((request) => {
  const requesterEmail = normalizeEmail(request.requesterEmail || "");
  const ownerEmail = normalizeEmail(request.ownerEmail || "");

  const isRequester =
    request.requesterId === currentId ||
    (currentEmail && requesterEmail === currentEmail);

  const isOwner =
    request.ownerId === currentId ||
    (currentEmail && ownerEmail === currentEmail);

  return isRequester || isOwner;
});

const pendingRequests = mySwapRequests.filter(
  (request) => request.status === "Pending"
).length;

const activeSwaps = mySwapRequests.filter(
  (request) => request.status === "Accepted"
).length;

const totalSwapRequests = mySwapRequests.length;



const successfulSwaps = mySwapRequests.filter(
  (request) => request.status === "Completed"
).length;

  // Logout function
const handleLogout = () => {
  clearCurrentUser();
  navigate("/login");
};

  return (
    <div className="dashboard-page">

      {/* NAVBAR */}
      <header className="dashboard-navbar">

        <Link to="/" className="dashboard-logo">
          ♻️ SwapWear
        </Link>
<Link to="/notifications">
  🔔 Notifications
</Link>

        <nav className="dashboard-nav">

          <Link to="/">Home</Link>

          <Link to="/browse">Browse</Link>

          <Link to="/list-clothing">
            List Clothing
          </Link>
          <Link to="/my-listings">
  My Listings
</Link>

          <Link to="/chat">
            Messages
          </Link>

          <button
            type="button"
            className="logout-link"
            onClick={handleLogout}
          >
            Logout
          </button>

        </nav>

      </header>

      <main className="dashboard-container">

        {/* WELCOME */}
        <section className="dashboard-welcome">

          <div>
            <small>MY DASHBOARD</small>

            <h1>Welcome back! 👋</h1>

            <p>
              Manage your clothes, swaps and requests.
            </p>
          </div>

          <Link
            to="/list-clothing"
            className="primary-button"
          >
            + List Clothing
          </Link>

        </section>

        {/* STATISTICS */}
        <section className="dashboard-stats">

          <div className="stat-card">
            <div className="stat-icon">👕</div>

            <div>
              <h2>{myListings.length}</h2>
<p>My Listings</p>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon">🔄</div>

            <div>
              <h2>{activeSwaps}</h2>
<p>Active Swaps</p>
            </div>
          </div>

          <div className="stat-card">
            <div className="stat-icon">📩</div>

            <div>
            <h2>{totalSwapRequests}</h2>
<p>Swap Requests</p>
            </div>
          </div>
          <div className="stat-card">
  <div className="stat-icon">⏳</div>
  <div>
    <h2>{pendingRequests}</h2>
    <p>Pending Requests</p>
  </div>
</div>

          <div className="stat-card">
            <div className="stat-icon">💚</div>

            <div>
              <h2>{successfulSwaps}</h2>
<p>Successful Swaps</p>
            </div>
          </div>

        </section>

        {/* MAIN CONTENT */}
        <section className="dashboard-content">

          {/* LEFT COLUMN */}
          <div>

            {/* MY LISTINGS */}
            <div className="dashboard-box">

              <div className="dashboard-box-header">

                <h2>My Listings</h2>

                <Link to="/my-listings">
  View All
</Link>

              </div>

              <div className="clothing-grid">
  {myListings.length === 0 ? (
    <p>You haven't listed any clothing yet.</p>
  ) : (
    myListings.slice(0, 3).map((item) => (
      <Link
        to={`/item/${item.id}`}
        className="dashboard-clothing-card"
        key={item.id}
      >
        <div className="clothing-image">
          {item.image ? (
            <img
              src={item.image}
              alt={item.name}
              style={{
                width: "100%",
                height: "100%",
                objectFit: "cover",
              }}
            />
          ) : (
            "👕"
          )}
        </div>

        <div className="clothing-info">
          <h3>{item.name}</h3>
          <p>
            Size {item.size} • {item.condition}
          </p>
        </div>
      </Link>
    ))
  )}
</div>
            </div>

            {/* RECENT SWAP REQUESTS */}

{/* RECENT SWAP REQUESTS */}
<div className="dashboard-box">

  <div className="dashboard-box-header">
    <h2>Recent Swap Requests</h2>

    <Link to="/swap-requests">
      View All
    </Link>
  </div>

  {mySwapRequests.length === 0 ? (
    <p>No swap requests yet.</p>
  ) : (
    mySwapRequests
      .slice()
      .sort(
        (a, b) =>
          new Date(b.createdAt || 0) -
          new Date(a.createdAt || 0)
      )
      .slice(0, 3)
      .map((request) => {
        const email = normalizeEmail(
          currentUser?.email || ""
        );

        const isOwner =
          request.ownerId === currentId ||
          normalizeEmail(request.ownerEmail || "") === email;

        return (
          <div className="request" key={request.id}>

            <div className="request-user">
              <div className="user-avatar">
                👤
              </div>

              <div>
                <strong>
                  {isOwner
                    ? request.requester || "SwapWear Member"
                    : request.owner || "SwapWear Member"}
                </strong>

                <span>
                  {isOwner
                    ? `Interested in your ${request.itemName || "clothing"}`
                    : `You requested ${request.itemName || "clothing"}`}
                </span>
              </div>
            </div>

            <span className="request-status">
              {request.status || "Pending"}
            </span>

          </div>
        );
      })
  )}

</div>


          </div>

          {/* RIGHT COLUMN */}
          <div>

            {/* PROFILE */}
            <div className="dashboard-box">

              <div className="dashboard-box-header">

                <h2>My Profile</h2>

                <Link to="/profile">
                  Edit
                </Link>

              </div>

              <div className="request-user">

                <div className="user-avatar">
                  👤
                </div>

                <div>
<strong>{currentUser?.name || "SwapWear Member"}</strong>
                  <span>
                    SwapWear Member
                  </span>
                </div>

              </div>

            </div>

            {/* QUICK ACTIONS */}
            <div className="dashboard-box">

              <div className="dashboard-box-header">

                <h2>Quick Actions</h2>

              </div>

              <div className="quick-actions">
                <Link
  to="/my-listings"
  className="quick-action"
>
  <div className="quick-action-icon">
    👕
  </div>

  <div>
    <strong>My Listings</strong>
    <span>Manage your clothing</span>
  </div>
</Link>

                {/* BROWSE */}
                <Link
                  to="/browse"
                  className="quick-action"
                >

                  <div className="quick-action-icon">
                    🔍
                  </div>

                  <div>
                    <strong>Browse</strong>
                    <span>Find clothes</span>
                  </div>

                </Link>

                {/* LIST ITEM */}
                <Link
                  to="/list-clothing"
                  className="quick-action"
                >

                  <div className="quick-action-icon">
                    ➕
                  </div>

                  <div>
                    <strong>List Item</strong>
                    <span>Add clothing</span>
                  </div>

                </Link>

                {/* SWAPS */}
                <Link
                  to="/swap-requests"
                  className="quick-action"
                >

                  <div className="quick-action-icon">
                    🔄
                  </div>

                  <div>
                    <strong>Swaps</strong>
                    <span>View requests</span>
                  </div>

                </Link>

                {/* MESSAGES */}
                <Link
                  to="/chat"
                  className="quick-action"
                >

                  <div className="quick-action-icon">
                    💬
                  </div>

                  <div>
                    <strong>Messages</strong>
                    <span>Chat with users</span>
                  </div>

                </Link>

              </div>

            </div>

          </div>

        </section>

      </main>

    </div>
  );
}

export default Dashboard;