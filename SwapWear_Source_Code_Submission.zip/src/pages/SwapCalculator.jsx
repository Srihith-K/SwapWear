
import { useState } from "react";
import { Link } from "react-router-dom";
import "./SwapCalculator.css";

const categoryPrices = {
  "T-Shirts": 600,
  Shirts: 800,
  Jeans: 1200,
  Dresses: 1500,
  Jackets: 2000,
  Hoodies: 1300,
  Trousers: 1000,
  Footwear: 1800,
};

const conditionMultipliers = {
  "Like New": 1,
  Excellent: 0.85,
  Good: 0.65,
  Fair: 0.4,
};
const brandMultipliers = {
  Nike: 1.2,
  Adidas: 1.2,
  Puma: 1.1,
  "Levi's": 1.25,
  Zara: 1.15,
  "H&M": 0.9,
  Uniqlo: 1.05,
  Westside: 0.9,
  Other: 0.8,
};

const initialItem = {
  name: "",
  brand: "Other",
  category: "T-Shirts",
  condition: "Good",
};

function estimateValue(item) {
  const basePrice = categoryPrices[item.category] || 600;
  const brandFactor = brandMultipliers[item.brand] || 0.8;
  const conditionFactor =
    conditionMultipliers[item.condition] || 0.65;

  return Math.round(
    basePrice * brandFactor * conditionFactor
  );
}

function SwapCalculator() {
  const [itemOne, setItemOne] = useState({
    ...initialItem,
    name: "My Clothing Item",
  });

  const [itemTwo, setItemTwo] = useState({
    ...initialItem,
    name: "Other Clothing Item",
  });

  const [compared, setCompared] = useState(false);

  const valueOne = estimateValue(itemOne);
  const valueTwo = estimateValue(itemTwo);

  const difference = Math.abs(valueOne - valueTwo);

  const differencePercent =
    Math.max(valueOne, valueTwo) > 0
      ? (difference / Math.max(valueOne, valueTwo)) * 100
      : 0;

  const fairSwap = differencePercent <= 15;

  const updateItem = (itemNumber, field, value) => {
    if (itemNumber === 1) {
      setItemOne((previous) => ({
        ...previous,
        [field]: value,
      }));
    } else {
      setItemTwo((previous) => ({
        ...previous,
        [field]: value,
      }));
    }

    setCompared(false);
  };

  const renderItemForm = (item, itemNumber) => (
    <section className="calculator-item-card">
      <div className="calculator-item-heading">
        <span>{itemNumber === 1 ? "👕" : "🧥"}</span>
        <div>
          <h2>{itemNumber === 1 ? "Your Item" : "Exchange Item"}</h2>
          <p>Enter clothing details</p>
        </div>
      </div>

      <div className="calculator-form-group">
        <label>Clothing Name</label>
        <input
          type="text"
          value={item.name}
          onChange={(e) =>
            updateItem(itemNumber, "name", e.target.value)
          }
          placeholder="Enter clothing name"
        />
      </div>

      <div className="calculator-form-group">
        <label>Category</label>
        <select
          value={item.category}
          onChange={(e) =>
            updateItem(itemNumber, "category", e.target.value)
          }
        >
          {Object.keys(categoryPrices).map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>
      </div>

      <div className="calculator-form-group">
        <label>Brand</label>
        <select
          value={item.brand}
          onChange={(e) =>
            updateItem(itemNumber, "brand", e.target.value)
          }
        >
          {Object.keys(brandMultipliers).map((brand) => (
            <option key={brand} value={brand}>
              {brand}
            </option>
          ))}
        </select>
      </div>

      <div className="calculator-form-group">
        <label>Condition</label>
        <select
          value={item.condition}
          onChange={(e) =>
            updateItem(itemNumber, "condition", e.target.value)
          }
        >
          {Object.keys(conditionMultipliers).map((condition) => (
            <option key={condition} value={condition}>
              {condition}
            </option>
          ))}
        </select>
      </div>

      <div className="calculator-estimate">
        <span>Estimated Value</span>
        <strong>₹{valueOne.toLocaleString("en-IN")}</strong>
      </div>
    </section>
  );

  return (
    <div className="swap-calculator-page">
      <header className="calculator-navbar">
        <Link to="/" className="calculator-logo">
          ♻️ SwapWear
        </Link>

        <nav>
          <Link to="/browse">Browse</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/swap-requests">Swap Requests</Link>
        </nav>
      </header>

      <main className="calculator-container">
        <section className="calculator-hero">
          <span>SMARTER CLOTHING EXCHANGE</span>
          <h1>Swap Value Calculator</h1>
          <p>
            Compare clothing values and discover whether your
            proposed exchange is approximately fair.
          </p>
        </section>

        <section className="calculator-grid">
          {renderItemForm(itemOne, 1)}
          {renderItemForm(itemTwo, 2)}
        </section>

        <button
          className="compare-swap-button"
          onClick={() => setCompared(true)}
        >
          ⚖️ Compare Clothing Values
        </button>

        {compared && (
          <section className="calculator-result">
            <span className="result-label">SWAP COMPARISON</span>

            <div className="comparison-values">
              <div>
                <small>Your Item</small>
                <strong>
                  ₹{valueOne.toLocaleString("en-IN")}
                </strong>
              </div>

              <span className="comparison-arrow">↔</span>

              <div>
                <small>Exchange Item</small>
                <strong>
                  ₹{valueTwo.toLocaleString("en-IN")}
                </strong>
              </div>
            </div>

            <div className="value-difference">
              Value Difference: ₹{difference.toLocaleString("en-IN")}
            </div>

            <div
              className={`fairness-result ${
                fairSwap ? "fair" : "unbalanced"
              }`}
            >
              <strong>
                {fairSwap
                  ? "✓ Approximately Fair Swap"
                  : "⚖ Value Difference Detected"}
              </strong>

              <p>
                {fairSwap
                  ? "Both items have similar estimated values. This may be a suitable exchange."
                  : valueOne > valueTwo
                    ? "Your item has a higher estimated value. Consider negotiating with the other user."
                    : "The exchange item has a higher estimated value. Consider discussing additional items or terms."}
              </p>
            </div>

            <p className="calculator-disclaimer">
              These are approximate estimates based on preset
              category, brand and condition factors. Actual swap
              value depends on item quality, demand and negotiation.
            </p>
          </section>
        )}
      </main>
    </div>
  );
}

export default SwapCalculator;
