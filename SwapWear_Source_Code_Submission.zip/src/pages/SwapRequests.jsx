import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import {
  getCurrentUser,
  getSwapRequests,
  saveSwapRequests,
  normalizeEmail,
  addNotification,
} from "../utils/storage";
import "./SwapRequests.css";

function SwapRequests() {
  const navigate = useNavigate();

const currentUser = getCurrentUser();

const [requests, setRequests] = useState(() => getSwapRequests());
const getStatusClass = (status) => {
  if (status === "Accepted") {
    return "status-accepted";
  }

  if (status === "Rejected") {
    return "status-rejected";
  }

  if (status === "Completed") {
    return "status-completed";
  }

  return "status-pending";
};

const currentEmail = normalizeEmail(currentUser?.email || "");
const currentId = currentUser?.id || currentEmail;

const visibleRequests = requests.filter((request) => {
  const requesterEmail = normalizeEmail(request.requesterEmail || "");
  const ownerEmail = normalizeEmail(request.ownerEmail || "");

  const isRequester =
    request.requesterId === currentId ||
    (currentEmail && requesterEmail === currentEmail);

  const isOwner =
    request.ownerId === currentId ||
    (currentEmail && ownerEmail === currentEmail);

  return isRequester || isOwner;
});

const updateRequestStatus = (requestId, newStatus) => {
  const request = requests.find(
    (item) => item.id === requestId
  );

  if (!request) return;

  const ownerEmail = normalizeEmail(request.ownerEmail || "");
  const requesterEmail = normalizeEmail(request.requesterEmail || "");

  const isOwner =
    request.ownerId === currentId ||
    (currentEmail && ownerEmail === currentEmail);

  const isRequester =
    request.requesterId === currentId ||
    (currentEmail && requesterEmail === currentEmail);

  if (newStatus === "Completed") {
    if (!isOwner && !isRequester) {
      alert("You are not authorized to complete this swap.");
      return;
    }

    if (request.status !== "Accepted") {
      alert("Only accepted swaps can be marked as completed.");
      return;
    }
  } else {
    if (!isOwner) {
      alert("Only the clothing owner can update this request.");
      return;
    }

    if (request.status !== "Pending") {
      alert("This request has already been processed.");
      return;
    }
  }

  const updatedRequests = requests.map((item) =>
    item.id === requestId
      ? {
          ...item,
          status: newStatus,
          updatedAt: new Date().toISOString(),
          ...(newStatus === "Completed"
            ? { completedAt: new Date().toISOString() }
            : {}),
        }
      : item
  );

  const saved = saveSwapRequests(updatedRequests);

  if (!saved) {
    alert("Unable to update request. Please try again.");
    return;
  }

  setRequests(updatedRequests);
  // Notify the other participant
const recipientEmail =
  newStatus === "Completed"
    ? (isOwner ? requesterEmail : ownerEmail)
    : requesterEmail;

if (recipientEmail) {
  const notificationMessages = {
    Accepted: "Your clothing swap request has been accepted.",
    Rejected: "Your clothing swap request has been rejected.",
    Completed: "Your clothing swap has been completed.",
  };

  addNotification({
    recipientEmail,
    type: `swap_${newStatus.toLowerCase()}`,
    title: `Swap ${newStatus}`,
    message: notificationMessages[newStatus],
    relatedId: requestId,
    link: "/swap-requests",
  });
}
};

  return (
    <div className="swap-requests-page">

      {/* Navbar */}
      <header className="swap-requests-navbar">

        <Link to="/" className="swap-requests-logo">
          ♻️ SwapWear
        </Link>

        <nav className="swap-requests-nav">
          <Link to="/">Home</Link>
          <Link to="/browse">Browse</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/list-clothing">List Clothing</Link>
          <Link to="/chat">Messages</Link>
        </nav>

      </header>

      {/* Main Content */}
      <main className="swap-requests-container">

        <div className="swap-requests-header">

          <div>
            <span className="section-label">
              SWAP ACTIVITY
            </span>

            <h1>
              Swap Requests
            </h1>

            <p>
              Manage your clothing swap requests and track their status.
            </p>
          </div>

          <Link
            to="/browse"
            className="browse-more-button"
          >
            Browse Clothes →
          </Link>

        </div>

        {/* Not Logged In */}
        {!currentUser ? (

          <section className="empty-requests-card">

            <div className="empty-icon">
              🔐
            </div>

            <h2>
              Login Required
            </h2>

            <p>
              Please login to view and manage your clothing swap requests.
            </p>

            <button
              className="login-request-button"
             onClick={() => navigate("/login")}
            >
              Login to Continue
            </button>

          </section>

        ) :visibleRequests.length === 0 ? (

          /* No Requests */
          <section className="empty-requests-card">

            <div className="empty-icon">
              🔄
            </div>

            <h2>
              No Swap Requests Yet
            </h2>

            <p>
              You haven't made or received any swap requests yet.
              Start browsing clothes and find something you like.
            </p>

            <Link
              to="/browse"
              className="start-browsing-button"
            >
              Start Browsing →
            </Link>

          </section>

        ) : (

          /* Requests */
          <section className="requests-section">

            {/* Summary */}
            <div className="requests-summary">

              <div className="summary-box">
                <span>Total Requests</span>
                <strong>{visibleRequests.length}</strong>
              </div>

              <div className="summary-box">
                <span>Pending</span>
                <strong>
                  {
                    visibleRequests.filter(
                      (request) =>
                        request.status === "Pending"
                    ).length
                  }
                </strong>
              </div>

              <div className="summary-box">
                <span>Accepted</span>
                <strong>
                  {
                    visibleRequests.filter(
                      (request) =>
                        request.status === "Accepted"
                    ).length
                  }
                </strong>
              </div>

              <div className="summary-box">
                <span>Rejected</span>
                <strong>
                  {
                    visibleRequests.filter(
                      (request) =>
                        request.status === "Rejected"
                    ).length
                  }
                </strong>
              </div>

              <div className="summary-box">
  <span>Completed</span>
  <strong>
    {
      visibleRequests.filter(
        (request) => request.status === "Completed"
      ).length
    }
  </strong>
</div>

            </div>

            {/* Request List */}
            <div className="requests-list">

              {
visibleRequests.map((request) => {
                const ownerEmail = normalizeEmail(request.ownerEmail || "");

const isOwner =
  request.ownerId === currentId ||
  (currentEmail && ownerEmail === currentEmail);

                const isPending =
                  request.status === "Pending";

                return (
                  <article
                    className="swap-request-card"
                    key={request.id}
                  >

                    {/* Item Image */}
                    <div className="request-item-image">
                      <span>
                        {request.emoji || "👕"}
                      </span>
                    </div>

                    {/* Information */}
                    <div className="request-information">

                      <div className="request-top-row">

                        <div>

                          <span className="request-category">
                            {request.category || "Clothing"}
                          </span>

                          <h2>
                            {request.itemName || "Clothing Item"}
                          </h2>

                          <p className="request-brand">
                            {request.brand || "SwapWear Member"}
                          </p>

                        </div>

                        <span
                          className={`request-status ${getStatusClass(
                            request.status
                          )}`}
                        >
                          {request.status || "Pending"}
                        </span>

                      </div>

                      {/* Request Details */}
                      <div className="request-details">

                        <div>
                          <small>
                            Requested By
                          </small>

                          <strong>
                            {request.requester ||
                              "SwapWear Member"}
                          </strong>
                        </div>

                        <div>
                          <small>
                            Owner
                          </small>

                          <strong>
                            {request.owner ||
                              "SwapWear Member"}
                          </strong>
                        </div>

                        <div>
                          <small>
                            Swap Value
                          </small>

                          <strong>
                            ₹{request.value || 0}
                          </strong>
                        </div>

                        <div>
                          <small>
                            Requested On
                          </small>

                          <strong>
                            {request.date || "Recently"}
                          </strong>
                        </div>

                      </div>

                      {/* Actions */}
                      <div className="request-actions">

                        <Link
                          to={`/item/${request.itemId}`}
                          className="view-request-button"
                        >
                          View Item
                        </Link>

                        <Link
                          to="/chat"
                          className="message-request-button"
                        >
                          💬 Message
                        </Link>

                        {/* Owner Controls */}
                        {isOwner && isPending && (
                          <div className="owner-request-actions">

                            <button
                              className="accept-request-button"
                              onClick={() =>
                                updateRequestStatus(
                                  request.id,
                                  "Accepted"
                                )
                              }
                            >
                              ✓ Accept
                            </button>

                            <button
                              className="reject-request-button"
                              onClick={() =>
                                updateRequestStatus(
                                  request.id,
                                  "Rejected"
                                )
                              }
                            >
                              ✕ Reject
                            </button>

                          </div>
                        )}

                        {request.status === "Accepted" && (
  <button
    type="button"
    className="accept-request-button"
    onClick={() =>
      updateRequestStatus(request.id, "Completed")
    }
  >
    ✓ Complete Swap
  </button>
)}
{request.status === "Completed" && (
  <div className="request-status-message accepted-message">
    ✓ This clothing swap has been completed successfully!
  </div>
)}

                      </div>

                      {/* Owner Information */}
                      {isOwner && isPending && (
                        <div className="owner-action-note">
                          You are the owner of this item. Choose whether
                          to accept or reject this swap request.
                        </div>
                      )}

                      {/* Accepted Message */}
                      {request.status === "Accepted" && (
                        <div className="request-status-message accepted-message">
                          ✓ This swap request has been accepted.
                        </div>
                      )}

                      {/* Rejected Message */}
                      {request.status === "Rejected" && (
                        <div className="request-status-message rejected-message">
                          This swap request has been rejected.
                        </div>
                      )}

                    </div>

                  </article>
                );
              })}

            </div>

          </section>
        )}

      </main>

    </div>
  );
}

export default SwapRequests;