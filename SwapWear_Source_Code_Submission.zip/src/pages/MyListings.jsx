
import { useState } from "react";
import { Link } from "react-router-dom";

import {
  getCurrentUser,
  getListings,
  saveListings,
  normalizeEmail,
} from "../utils/storage";

import "./Listings.css";

function MyListings() {
  const [currentUser] = useState(() => getCurrentUser());
  const [myListings, setMyListings] = useState(() => {
    const user = getCurrentUser();
    if (!user?.email) return [];
    const email = normalizeEmail(user.email);
    const userId = user.id || email;
    return getListings().filter(
      (listing) =>
        listing.ownerId === userId ||
        normalizeEmail(listing.ownerEmail || "") === email
    );
  });

  const [editingId, setEditingId] = useState(null);
  const [editForm, setEditForm] = useState({});
  const [error, setError] = useState("");
  const [success, setSuccess] = useState("");

  // Check whether a listing belongs to the logged-in user
  const isMyListing = (listing, user) => {
    if (!listing || !user?.email) return false;

    const email = normalizeEmail(user.email);
    const userId = user.id || email;

    return (
      listing.ownerId === userId ||
      normalizeEmail(listing.ownerEmail || "") === email
    );
  };

  // Refresh the user's listings after an edit.
  const loadMyListings = () => {
    const user = getCurrentUser();
    if (!user?.email) {
      setMyListings([]);
      return;
    }
    const userListings = getListings().filter((listing) =>
      isMyListing(listing, user)
    );
    setMyListings(userListings);
  };

  // Start editing a listing
  const handleEdit = (item) => {
    setEditingId(item.id);

    setEditForm({
      name: item.name || "",
      brand: item.brand || "",
      category: item.category || "",
      size: item.size || "",
      condition: item.condition || "Good",
      location: item.location || "",
      value: item.value ?? "",
      description: item.description || "",
    });

    setError("");
    setSuccess("");
  };

  // Update form values
  const handleEditChange = (e) => {
    const { name, value } = e.target;

    setEditForm((previous) => ({
      ...previous,
      [name]: value,
    }));
  };

  // Save edited listing
  const handleUpdate = (e) => {
    e.preventDefault();

    if (!currentUser) return;

    if (
      !editForm.name.trim() ||
      !editForm.brand.trim() ||
      !editForm.category.trim() ||
      !editForm.size.trim() ||
      !editForm.location.trim()
    ) {
      setError("Please fill in all required fields.");
      return;
    }

    const value = Number(editForm.value);

    if (!Number.isFinite(value) || value <= 0) {
      setError("Please enter a valid swap value greater than zero.");
      return;
    }

    const allListings = getListings();

    const updatedListings = allListings.map((listing) => {
      if (
        String(listing.id) !== String(editingId) ||
        !isMyListing(listing, currentUser)
      ) {
        return listing;
      }

      return {
        ...listing,
        name: editForm.name.trim(),
        brand: editForm.brand.trim(),
        category: editForm.category.trim(),
        size: editForm.size.trim(),
        condition: editForm.condition,
        location: editForm.location.trim(),
        value,
        description: editForm.description.trim(),
        updatedAt: new Date().toISOString(),
      };
    });

    const saved = saveListings(updatedListings);

    if (!saved) {
      setError("Unable to update listing. Please try again.");
      return;
    }

    setEditingId(null);
    setEditForm({});
    setError("");
    setSuccess("Your listing has been updated successfully!");

    loadMyListings();
  };

  // Cancel editing
  const handleCancelEdit = () => {
    setEditingId(null);
    setEditForm({});
    setError("");
  };

  // Delete listing
  const handleDelete = (listingId) => {
    if (!currentUser) return;

    const confirmDelete = window.confirm(
      "Are you sure you want to delete this listing? This action cannot be undone."
    );

    if (!confirmDelete) return;

    const allListings = getListings();

    const targetListing = allListings.find(
      (listing) =>
        String(listing.id) === String(listingId) &&
        isMyListing(listing, currentUser)
    );

    if (!targetListing) {
      setError("Listing not found or you do not have permission to delete it.");
      return;
    }

    const updatedListings = allListings.filter(
      (listing) =>
        !(
          String(listing.id) === String(listingId) &&
          isMyListing(listing, currentUser)
        )
    );

    const saved = saveListings(updatedListings);

    if (!saved) {
      setError("Unable to delete listing. Please try again.");
      return;
    }

    setMyListings((previous) =>
      previous.filter(
        (listing) => String(listing.id) !== String(listingId)
      )
    );

    setSuccess("Listing deleted successfully!");
    setError("");

    if (String(editingId) === String(listingId)) {
      setEditingId(null);
      setEditForm({});
    }
  };

  // Change listing availability
  const handleToggleStatus = (item) => {
    if (!currentUser || !isMyListing(item, currentUser)) return;

    const newStatus =
      item.status === "Available" ? "Unavailable" : "Available";

    const confirmChange = window.confirm(
      `Change "${item.name}" status to ${newStatus}?`
    );

    if (!confirmChange) return;

    const allListings = getListings();

    const updatedListings = allListings.map((listing) => {
      if (
        String(listing.id) === String(item.id) &&
        isMyListing(listing, currentUser)
      ) {
        return {
          ...listing,
          status: newStatus,
          updatedAt: new Date().toISOString(),
        };
      }

      return listing;
    });

    const saved = saveListings(updatedListings);

    if (!saved) {
      setError("Unable to update availability. Please try again.");
      return;
    }

    setMyListings((previous) =>
      previous.map((listing) =>
        String(listing.id) === String(item.id)
          ? { ...listing, status: newStatus }
          : listing
      )
    );

    setSuccess(`Listing marked as ${newStatus}.`);
    setError("");
  };

  // Logged-out state
  if (!currentUser) {
    return (
      <div className="listings-page">
        <header className="listings-navbar">
          <Link to="/" className="listings-logo">
            ♻️ SwapWear
          </Link>

          <nav className="listings-nav">
            <Link to="/">Home</Link>
            <Link to="/browse">Browse</Link>
            <Link to="/login">Login</Link>
          </nav>
        </header>

        <main className="listings-container">
          <section className="listings-header">
            <div>
              <span className="section-label">MY CLOSET</span>
              <h1>My Listings</h1>
              <p>
                Please login to view and manage your clothing listings.
              </p>
            </div>

            <Link to="/login" className="list-clothing-button">
              Login
            </Link>
          </section>
        </main>
      </div>
    );
  }

  return (
    <div className="listings-page">

      {/* NAVBAR */}
      <header className="listings-navbar">
        <Link to="/" className="listings-logo">
          ♻️ SwapWear
        </Link>

        <nav className="listings-nav">
          <Link to="/">Home</Link>
          <Link to="/browse">Browse</Link>
          <Link to="/list-clothing">List Clothing</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/chat">Messages</Link>
          <Link to="/profile">Profile</Link>
        </nav>
      </header>

      {/* MAIN CONTENT */}
      <main className="listings-container">

        {/* PAGE HEADER */}
        <section className="listings-header">
          <div>
            <span className="section-label">MY CLOSET</span>
            <h1>My Listings</h1>
            <p>
              Manage the clothes you have listed for swapping.
            </p>
          </div>

          <Link
            to="/list-clothing"
            className="list-clothing-button"
          >
            + List Clothing
          </Link>
        </section>

        {/* NOTIFICATIONS */}
        {error && (
          <p role="alert" style={{ color: "#c0392b", marginBottom: 16 }}>
            {error}
          </p>
        )}

        {success && (
          <p role="status" style={{ color: "#247341", marginBottom: 16 }}>
            {success}
          </p>
        )}

        {/* RESULT COUNT */}
        <div className="results-row">
          <p>
            <strong>{myListings.length}</strong>{" "}
            {myListings.length === 1 ? "item" : "items"} listed
          </p>
        </div>

        {/* EMPTY STATE */}
        {myListings.length === 0 ? (
          <section className="empty-listings">
            <div className="empty-listings-icon">
              👕
            </div>

            <h2>No listings yet</h2>

            <p>
              You haven't listed any clothing yet.
              Give your clothes a second life!
            </p>

            <Link
              to="/list-clothing"
              className="list-clothing-button"
            >
              + List Your First Item
            </Link>
          </section>
        ) : (

          /* LISTINGS GRID */
          <section className="listings-grid">
            {myListings.map((item) => (
              <article
                className="listing-card"
                key={item.id}
              >

                {/* IMAGE */}
                <div className="listing-image">
                  {item.image ? (
                    <img
                      src={item.image}
                      alt={item.name}
                    />
                  ) : (
                    <span>👕</span>
                  )}

                  <span className="condition-badge">
                    {item.condition}
                  </span>
                </div>

                {/* INFORMATION */}
                <div className="listing-info">

                  {editingId === item.id ? (

                    /* EDIT FORM */
                    <form onSubmit={handleUpdate}>

                      <h2>Edit Listing</h2>

                      <div className="profile-field">
                        <label>Item Name</label>
                        <input
                          name="name"
                          value={editForm.name}
                          onChange={handleEditChange}
                          required
                        />
                      </div>

                      <div className="profile-field">
                        <label>Brand</label>
                        <input
                          name="brand"
                          value={editForm.brand}
                          onChange={handleEditChange}
                          required
                        />
                      </div>

                      <div className="profile-field">
                        <label>Category</label>
                        <input
                          name="category"
                          value={editForm.category}
                          onChange={handleEditChange}
                          required
                        />
                      </div>

                      <div className="profile-field">
                        <label>Size</label>
                        <input
                          name="size"
                          value={editForm.size}
                          onChange={handleEditChange}
                          required
                        />
                      </div>

                      <div className="profile-field">
                        <label>Condition</label>
                        <select
                          name="condition"
                          value={editForm.condition}
                          onChange={handleEditChange}
                        >
                          <option value="Like New">Like New</option>
                          <option value="Excellent">Excellent</option>
                          <option value="Good">Good</option>
                          <option value="Fair">Fair</option>
                        </select>
                      </div>

                      <div className="profile-field">
                        <label>Location</label>
                        <input
                          name="location"
                          value={editForm.location}
                          onChange={handleEditChange}
                          required
                        />
                      </div>

                      <div className="profile-field">
                        <label>Swap Value (₹)</label>
                        <input
                          name="value"
                          type="number"
                          min="1"
                          value={editForm.value}
                          onChange={handleEditChange}
                          required
                        />
                      </div>

                      <div className="profile-field">
                        <label>Description</label>
                        <textarea
                          name="description"
                          value={editForm.description}
                          onChange={handleEditChange}
                          rows="3"
                        />
                      </div>

                      <div className="listing-actions">
                        <button
                          type="submit"
                          className="view-button"
                        >
                          Save Changes
                        </button>

                        <button
                          type="button"
                          className="delete-listing-button"
                          onClick={handleCancelEdit}
                        >
                          Cancel
                        </button>
                      </div>

                    </form>

                  ) : (

                    /* NORMAL LISTING VIEW */
                    <>
                      <span className="listing-category">
                        {item.category}
                      </span>

                      <h2>{item.name}</h2>

                      <p className="listing-details">
                        {item.brand} • Size {item.size}
                      </p>

                      <p className="listing-location">
                        📍 {item.location}
                      </p>

                      <div className="listing-status">
                        <span className="status-dot"></span>
                        {item.status || "Available"}
                      </div>

                      <div className="listing-footer">

                        <div>
                          <span>Swap value</span>
                          <strong>
                            ₹{Number(item.value).toLocaleString("en-IN")}
                          </strong>
                        </div>

                        <div className="listing-actions">

                          <Link
                            to={`/item/${item.id}`}
                            className="view-button"
                          >
                            View
                          </Link>

                          <button
                            type="button"
                            className="view-button"
                            onClick={() => handleEdit(item)}
                          >
                            Edit
                          </button>

                          <button
                            type="button"
                            className="delete-listing-button"
                            onClick={() => handleDelete(item.id)}
                          >
                            Delete
                          </button>

                        </div>

                      </div>

                      <button
                        type="button"
                        className="view-button"
                        style={{ marginTop: 12, width: "100%" }}
                        onClick={() => handleToggleStatus(item)}
                      >
                        {item.status === "Available"
                          ? "Mark Unavailable"
                          : "Mark Available"}
                      </button>
                    </>
                  )}

                </div>
              </article>
            ))}
          </section>
        )}

      </main>
    </div>
  );
}

export default MyListings;
