import {
  getCurrentUser,
  getSwapRequests,
  saveSwapRequests,
  normalizeEmail,
  addNotification,
} from "../utils/storage";
import { Link, useNavigate, useParams } from "react-router-dom";
import { useState } from "react";
import "./ItemDetails.css";

// Existing marketplace items
const clothingItems = [
  {
    id: 1,
    name: "Classic T-Shirt",
    brand: "H&M",
    category: "T-Shirts",
    size: "M",
    condition: "Good",
    location: "Hyderabad",
    value: 500,
    emoji: "👕",
    description:
      "A comfortable classic T-shirt in good condition. Perfect for casual everyday wear.",
    owner: "Rahul",
  },
  {
    id: 2,
    name: "Denim Jeans",
    brand: "Levi's",
    category: "Jeans",
    size: "32",
    condition: "Excellent",
    location: "Bangalore",
    value: 900,
    emoji: "👖",
    description:
      "Classic denim jeans in excellent condition with minimal signs of wear.",
    owner: "Ananya",
  },
  {
    id: 3,
    name: "Casual Jacket",
    brand: "Zara",
    category: "Jackets",
    size: "L",
    condition: "Like New",
    location: "Chennai",
    value: 1100,
    emoji: "🧥",
    description:
      "Stylish casual jacket that has been worn only a few times and is in like-new condition.",
    owner: "Arjun",
  },
  {
    id: 4,
    name: "Summer Dress",
    brand: "Westside",
    category: "Dresses",
    size: "M",
    condition: "Good",
    location: "Hyderabad",
    value: 750,
    emoji: "👗",
    description:
      "Lightweight summer dress suitable for casual outings and everyday use.",
    owner: "Priya",
  },
  {
    id: 5,
    name: "Classic Hoodie",
    brand: "Puma",
    category: "Hoodies",
    size: "XL",
    condition: "Excellent",
    location: "Mumbai",
    value: 850,
    emoji: "🧥",
    description:
      "Warm and comfortable hoodie in excellent condition.",
    owner: "Karthik",
  },
  {
    id: 6,
    name: "Cotton Casual Shirt",
    brand: "Uniqlo",
    category: "Shirts",
    size: "M",
    condition: "Like New",
    location: "Pune",
    value: 700,
    emoji: "👔",
    description:
      "Soft cotton casual shirt in like-new condition.",
    owner: "Rahul",
  },
  {
    id: 7,
    name: "Straight Fit Trousers",
    brand: "Westside",
    category: "Trousers",
    size: "32",
    condition: "Excellent",
    location: "Hyderabad",
    value: 800,
    emoji: "👖",
    description:
      "Comfortable straight-fit trousers in excellent condition.",
    owner: "Ananya",
  },
  {
    id: 8,
    name: "Graphic Print T-Shirt",
    brand: "Puma",
    category: "T-Shirts",
    size: "L",
    condition: "Good",
    location: "Delhi",
    value: 600,
    emoji: "👕",
    description:
      "Graphic print T-shirt with a comfortable fit and good overall condition.",
    owner: "Arjun",
  },
];

function ItemDetails() {
  const { id } = useParams();
  const navigate = useNavigate();

  const [swapRequested, setSwapRequested] = useState(false);

  // Find user-created listing in localStorage
  let userListing = null;

  try {
    const savedListings = JSON.parse(
      localStorage.getItem("swapwear_listings") || "[]"
    );

    if (Array.isArray(savedListings)) {
      userListing = savedListings.find(
        (listing) => String(listing.id) === String(id)
      );
    }
  } catch (error) {
    console.error("Error loading user listings:", error);
  }

  // Convert user-created listing to the ItemDetails format
  const customItem = userListing
    ? {
        ...userListing,
        owner: userListing.ownerName || "SwapWear Member",
        emoji: "👕",
        description:
          userListing.description || "No description provided.",
      }
    : null;

  // Search custom listings first, then existing marketplace items
  const item =
    customItem ||
    clothingItems.find(
      (clothing) => clothing.id === Number(id)
    );

  if (!item) {
    return (
      <div className="item-not-found">
        <h1>Item Not Found</h1>

        <p>
          The clothing item you are looking for does not exist.
        </p>

        <Link to="/browse" className="back-to-browse">
          ← Back to Browse
        </Link>
      </div>
    );
  }


const handleRequestSwap = () => {
  if (item.status === "Unavailable") {
    alert("Sorry, this clothing item is currently unavailable.");
    return;
  }

  const currentUser = getCurrentUser();

  if (!currentUser || !currentUser.email) {
    navigate("/login");
    return;
  }

  const requesterEmail = normalizeEmail(currentUser.email);
  const requesterId = currentUser.id || requesterEmail;

  const ownerEmail = normalizeEmail(item.ownerEmail || "");
  const ownerId = item.ownerId || ownerEmail || null;

  // Prevent users from requesting their own listings
  if (
    (ownerId && ownerId === requesterId) ||
    (ownerEmail && ownerEmail === requesterEmail)
  ) {
    alert("You cannot request a swap for your own listing.");
    return;
  }

  const existingRequests = getSwapRequests();

  // Prevent duplicate requests from the same user
  const alreadyRequested = existingRequests.some(
    (request) =>
      String(request.itemId) === String(item.id) &&
      (
        request.requesterId === requesterId ||
        normalizeEmail(request.requesterEmail || "") === requesterEmail
      )
  );

  if (alreadyRequested) {
    setSwapRequested(true);
    alert("You have already requested this item.");
    return;
  }

  const newRequest = {
    id: `request_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,

    itemId: item.id,
    itemName: item.name,
    brand: item.brand,
    category: item.category,
    image: item.image || "",
    emoji: item.emoji || "👕",
    value: item.value,

    requester: currentUser.name || "SwapWear Member",
    requesterId,
    requesterEmail,

    owner: item.ownerName || item.owner || "SwapWear Member",
    ownerId,
    ownerEmail,

    status: "Pending",
    date: new Date().toLocaleDateString("en-IN"),
    createdAt: new Date().toISOString(),
  };

  const saved = saveSwapRequests([
    ...existingRequests,
    newRequest,
  ]);

  if (!saved) {
    alert("Unable to send your swap request. Please try again.");
    return;
  }

setSwapRequested(true);

// Notify the clothing owner
if (ownerEmail) {
  addNotification({
    recipientEmail: ownerEmail,
    type: "swap_request",
    title: "New Swap Request",
    message: `${currentUser.name || "A member"} requested your ${item.name}.`,
    relatedId: newRequest.id,
    link: "/swap-requests",
  });
}};


  return (
    <div className="item-details-page">

      {/* NAVBAR */}
      <header className="item-details-navbar">
        <Link to="/" className="item-details-logo">
          ♻️ SwapWear
        </Link>

        <nav className="item-details-nav">
          <Link to="/">Home</Link>
          <Link to="/browse">Browse</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/list-clothing">List Clothing</Link>
          <Link to="/chat">Messages</Link>
        </nav>
      </header>

      {/* MAIN CONTENT */}
      <main className="item-details-container">

        <Link to="/browse" className="back-link">
          ← Back to Browse
        </Link>

        <section className="item-details-card">

          {/* ITEM IMAGE */}
          <div className="item-image-section">
            <div
              className="large-item-image"
              style={{ overflow: "hidden" }}
            >
              {item.image ? (
                <img
                  src={item.image}
                  alt={item.name}
                  style={{
                    width: "100%",
                    height: "100%",
                    objectFit: "cover",
                    display: "block",
                  }}
                />
              ) : (
                <span>{item.emoji || "👕"}</span>
              )}
            </div>
          </div>

          {/* ITEM INFORMATION */}
          <div className="item-information">

            <div className="item-category">
              {item.category}
            </div>

            <h1>{item.name}</h1>

            <p className="item-brand">
              {item.brand}
            </p>

            <div className="item-condition">
              <span>{item.condition}</span>

              <span>
                📍 {item.location}
              </span>
            </div>

            {/* DETAILS */}
            <div className="item-details-grid">

              <div>
                <small>Size</small>
                <strong>{item.size}</strong>
              </div>

              <div>
                <small>Condition</small>
                <strong>{item.condition}</strong>
              </div>

              <div>
                <small>Brand</small>
                <strong>{item.brand}</strong>
              </div>

              <div>
                <small>Location</small>
                <strong>{item.location}</strong>
              </div>

            </div>

            {/* DESCRIPTION */}
            <div className="item-description">
              <h2>Description</h2>

              <p>{item.description}</p>
            </div>

            {/* SWAP VALUE */}
            <div className="swap-value-box">
              <div>
                <small>Estimated Swap Value</small>

                <strong>
                  ₹{Number(item.value).toLocaleString("en-IN")}
                </strong>
              </div>
            </div>

            {/* OWNER */}
            <div className="owner-box">

              <div className="owner-avatar">
                👤
              </div>

              <div>
                <small>Listed by</small>

                <strong>{item.owner}</strong>

                <span>SwapWear Member</span>
              </div>

            </div>

            {/* ACTIONS */}
            <div className="item-actions">

             <button
  className="request-swap-button"
  onClick={handleRequestSwap}
  disabled={swapRequested || item.status === "Unavailable"}
>
  {item.status === "Unavailable"
    ? "Currently Unavailable"
    : swapRequested
      ? "✓ Swap Request Sent"
      : "🔄 Request Swap"}
</button>

            {item.ownerId || item.ownerEmail ? (
  <Link
    to={`/chat?itemId=${encodeURIComponent(item.id)}`}
    className="message-owner-button"
  >
    💬 Message Owner
  </Link>
) : (
  <button
    type="button"
    className="message-owner-button"
    disabled
    title="Messaging is available for registered members"
  >
    💬 Message Owner
  </button>
)}

            </div>

            {/* SUCCESS MESSAGE */}
            {swapRequested && (
              <div className="swap-success-message">
                <strong>
                  Swap request sent successfully!
                </strong>

                <p>
                  Your request is now pending. You can track it
                  from the Swap Requests page.
                </p>

                <Link to="/swap-requests">
                  View Swap Requests →
                </Link>
              </div>
            )}

          </div>
        </section>

      </main>
    </div>
  );
}

export default ItemDetails;
