import {
  getCurrentUser,
  getListings,
  saveListings,
} from "../utils/storage";
import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import "./ListClothing.css";

function ListClothing() {
  const navigate = useNavigate();

  const [formData, setFormData] = useState({
    name: "",
    category: "",
    size: "",
    condition: "",
    brand: "",
    location: "",
    description: "",
    value: "",
    image: "",
  });

  const [successMessage, setSuccessMessage] = useState("");

  const handleChange = (event) => {
    const { id, value } = event.target;

    setFormData((previous) => ({
      ...previous,
      [id]: value,
    }));
  };

  const handleImageChange = (event) => {
    const file = event.target.files[0];

    if (!file) return;

    if (file.size > 5 * 1024 * 1024) {
      alert("Image must be smaller than 5MB.");
      event.target.value = "";
      return;
    }

    const reader = new FileReader();

    reader.onload = () => {
      setFormData((previous) => ({
        ...previous,
        image: reader.result,
      }));
    };

    reader.readAsDataURL(file);
  };


const handleSubmit = (event) => {
  event.preventDefault();

  const user = getCurrentUser();

  if (!user || !user.email) {
    alert("Please login before creating a listing.");
    navigate("/login");
    return;
  }

  if (
    !formData.name.trim() ||
    !formData.category ||
    !formData.size ||
    !formData.condition ||
    !formData.brand.trim() ||
    !formData.location.trim() ||
    !formData.description.trim() ||
    !formData.value
  ) {
    alert("Please fill in all required fields.");
    return;
  }

  const value = Number(formData.value);

  if (!Number.isFinite(value) || value <= 0) {
    alert("Please enter a valid swap value greater than zero.");
    return;
  }

  const existingListings = getListings();

  const newListing = {
    id: `listing_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
    name: formData.name.trim(),
    category: formData.category,
    size: formData.size,
    condition: formData.condition,
    brand: formData.brand.trim(),
    location: formData.location.trim(),
    description: formData.description.trim(),
    value,
    image: formData.image,
    ownerId: user.id || user.email.trim().toLowerCase(),
    ownerEmail: user.email.trim().toLowerCase(),
    ownerName: user.name || "User",
    createdAt: new Date().toISOString(),
    status: "Available",
  };

  const saved = saveListings([...existingListings, newListing]);

  if (!saved) {
    alert("Unable to save your listing. Please try again.");
    return;
  }

  setFormData({
    name: "",
    category: "",
    size: "",
    condition: "",
    brand: "",
    location: "",
    description: "",
    value: "",
    image: "",
  });

  setSuccessMessage("Your clothing has been listed successfully! 🎉");

  window.scrollTo({ top: 0, behavior: "smooth" });

  setTimeout(() => {
    setSuccessMessage("");
  }, 4000);
};


  return (
    <div className="list-clothing-page">

      {/* NAVBAR */}
      <header className="listing-form-navbar">
        <Link to="/" className="listing-form-logo">
          ♻️ SwapWear
        </Link>

        <nav className="listing-form-nav">
          <Link to="/">Home</Link>
          <Link to="/browse">Browse</Link>
          <Link to="/list-clothing">List Clothing</Link>
          <Link to="/chat">Messages</Link>

          <Link to="/dashboard" className="logout-link">
            Dashboard
          </Link>
        </nav>
      </header>

      {/* MAIN CONTENT */}
      <main className="listing-form-container">

        {/* PAGE HEADER */}
        <section className="listing-form-header">
          <div>
            <span>SELL / SWAP</span>

            <h1>List Your Clothing</h1>

            <p>
              Give your clothes a second life by adding them to
              the SwapWear marketplace.
            </p>
          </div>

          <Link to="/browse" className="back-button">
            ← Browse Clothes
          </Link>
        </section>

        {/* SUCCESS MESSAGE */}
        {successMessage && (
          <div className="listing-success-message">
            {successMessage}
          </div>
        )}

        {/* FORM CARD */}
        <section className="listing-form-card">

          <div className="form-card-title">
            <h2>Clothing Details</h2>

            <p>
              Enter the details of the clothing item you want to swap.
            </p>
          </div>

          <form onSubmit={handleSubmit}>

            {/* CLOTHING NAME */}
            <div className="form-group">
              <label htmlFor="name">
                Clothing Name
              </label>

              <input
                id="name"
                type="text"
                placeholder="e.g. Classic T-Shirt"
                value={formData.name}
                onChange={handleChange}
              />
            </div>

            {/* CATEGORY + SIZE */}
            <div className="form-row">

              <div className="form-group">
                <label htmlFor="category">
                  Category
                </label>

                <select
                  id="category"
                  value={formData.category}
                  onChange={handleChange}
                >
                  <option value="" disabled>
                    Select category
                  </option>

                  <option value="T-Shirts">T-Shirts</option>
                  <option value="Shirts">Shirts</option>
                  <option value="Jeans">Jeans</option>
                  <option value="Dresses">Dresses</option>
                  <option value="Jackets">Jackets</option>
                  <option value="Hoodies">Hoodies</option>
                  <option value="Trousers">Trousers</option>
                  <option value="Footwear">Footwear</option>
                </select>
              </div>

              <div className="form-group">
                <label htmlFor="size">
                  Size
                </label>

                <select
                  id="size"
                  value={formData.size}
                  onChange={handleChange}
                >
                  <option value="" disabled>
                    Select size
                  </option>

                  <option value="XS">XS</option>
                  <option value="S">S</option>
                  <option value="M">M</option>
                  <option value="L">L</option>
                  <option value="XL">XL</option>
                  <option value="XXL">XXL</option>
                  <option value="28">28</option>
                  <option value="30">30</option>
                  <option value="32">32</option>
                  <option value="34">34</option>
                  <option value="36">36</option>
                  <option value="38">38</option>
                </select>
              </div>

            </div>

            {/* CONDITION */}
            <div className="form-group">
              <label htmlFor="condition">
                Condition
              </label>

              <select
                id="condition"
                value={formData.condition}
                onChange={handleChange}
              >
                <option value="" disabled>
                  Select condition
                </option>

                <option value="Like New">Like New</option>
                <option value="Excellent">Excellent</option>
                <option value="Good">Good</option>
                <option value="Fair">Fair</option>
              </select>
            </div>

            {/* BRAND */}
            <div className="form-group">
              <label htmlFor="brand">
                Brand
              </label>

              <input
                id="brand"
                type="text"
                placeholder="e.g. Nike, Levi's, Zara"
                value={formData.brand}
                onChange={handleChange}
              />
            </div>

            {/* LOCATION */}
            <div className="form-group">
              <label htmlFor="location">
                Location
              </label>

              <input
                id="location"
                type="text"
                placeholder="e.g. Hyderabad"
                value={formData.location}
                onChange={handleChange}
              />
            </div>

            {/* DESCRIPTION */}
            <div className="form-group">
              <label htmlFor="description">
                Description
              </label>

              <textarea
                id="description"
                rows="5"
                placeholder="Describe the clothing item..."
                value={formData.description}
                onChange={handleChange}
              ></textarea>
            </div>

            {/* SWAP VALUE */}
            <div className="form-group">
              <label htmlFor="value">
                Estimated Swap Value
              </label>

              <div className="price-input">
                <span>₹</span>

                <input
                  id="value"
                  type="number"
                  placeholder="500"
                  min="0"
                  value={formData.value}
                  onChange={handleChange}
                />
              </div>
            </div>

            {/* IMAGE UPLOAD */}
            <div className="form-group">
              <label>
                Clothing Image
              </label>

              <label className="image-upload">

                <span className="upload-icon">
                  📷
                </span>

                <strong>
                  Upload a clothing photo
                </strong>

                <small>
                  PNG, JPG or JPEG up to 5MB
                </small>

                <input
                  type="file"
                  accept="image/png,image/jpeg"
                  onChange={handleImageChange}
                />

                {formData.image && (
                  <small>
                    ✓ Image selected
                  </small>
                )}

              </label>
            </div>

            {/* BUTTONS */}
            <div className="form-actions">

              <Link
                to="/dashboard"
                className="cancel-button"
              >
                Cancel
              </Link>

              <button
                type="submit"
                className="submit-listing-button"
              >
                + Create Listing
              </button>

            </div>

          </form>

        </section>

      </main>

    </div>
  );
}

export default ListClothing;