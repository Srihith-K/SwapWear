import { useState } from "react"
import { Link } from "react-router-dom"
import "./Listings.css"

const clothes = [
  {
    id: 1,
    emoji: "👕",
    name: "Classic Cotton T-Shirt",
    category: "T-Shirt",
    size: "M",
    condition: "Good",
    brand: "H&M",
    location: "Hyderabad",
    value: 500,
  },
  {
    id: 2,
    emoji: "👖",
    name: "Slim Fit Denim Jeans",
    category: "Jeans",
    size: "32",
    condition: "Excellent",
    brand: "Levi's",
    location: "Bangalore",
    value: 1200,
  },
  {
    id: 3,
    emoji: "🧥",
    name: "Casual Denim Jacket",
    category: "Jacket",
    size: "L",
    condition: "Like New",
    brand: "Zara",
    location: "Chennai",
    value: 1800,
  },
  {
    id: 4,
    emoji: "👗",
    name: "Floral Summer Dress",
    category: "Dress",
    size: "S",
    condition: "Good",
    brand: "Mango",
    location: "Mumbai",
    value: 1000,
  },
  {
    id: 5,
    emoji: "👚",
    name: "Oversized Casual Shirt",
    category: "Shirt",
    size: "L",
    condition: "Excellent",
    brand: "Uniqlo",
    location: "Pune",
    value: 900,
  },
  {
    id: 6,
    emoji: "🧶",
    name: "Warm Knit Sweater",
    category: "Sweater",
    size: "M",
    condition: "Like New",
    brand: "H&M",
    location: "Delhi",
    value: 1300,
  },
  {
    id: 7,
    emoji: "👟",
    name: "Classic Casual Sneakers",
    category: "Shoes",
    size: "9",
    condition: "Good",
    brand: "Nike",
    location: "Hyderabad",
    value: 2000,
  },
  {
    id: 8,
    emoji: "🩳",
    name: "Comfort Cotton Shorts",
    category: "Shorts",
    size: "M",
    condition: "Excellent",
    brand: "Puma",
    location: "Bangalore",
    value: 700,
  },
]

function Listings() {
  const [currentUser] = useState(() => {
    try {
      const savedUser = localStorage.getItem("swapwear_current_user");
      return savedUser ? JSON.parse(savedUser) : null;
    } catch {
      return null;
    }
  });
  const [wishlist, setWishlist] = useState(() => {
    try {
      const savedUser = localStorage.getItem("swapwear_current_user");
      if (!savedUser) return [];
      const user = JSON.parse(savedUser);
      if (!user?.email) return [];
      const savedWishlist = localStorage.getItem(
        `swapwear_wishlist_${user.email}`
      );
      return savedWishlist ? JSON.parse(savedWishlist) : [];
    } catch {
      return [];
    }
  });

  // Add or remove item from wishlist
  const toggleWishlist = (item) => {
    // User must be logged in
    if (!currentUser) {
      alert("Please login to add items to your wishlist.")
      return
    }

    const userKey = `swapwear_wishlist_${currentUser.email}`

    const alreadySaved = wishlist.some(
      (wishlistItem) => wishlistItem.id === item.id
    )

    let updatedWishlist

    if (alreadySaved) {
      updatedWishlist = wishlist.filter(
        (wishlistItem) => wishlistItem.id !== item.id
      )
    } else {
      updatedWishlist = [...wishlist, item]
    }

    setWishlist(updatedWishlist)

    localStorage.setItem(
      userKey,
      JSON.stringify(updatedWishlist)
    )
  }

  // Check whether an item is already in wishlist
  const isWishlisted = (itemId) => {
    return wishlist.some(
      (wishlistItem) => wishlistItem.id === itemId
    )
  }

  return (
    <div className="listings-page">

      {/* NAVBAR */}
      <nav className="listings-navbar">

        <Link to="/" className="listings-logo">
          SwapWear
        </Link>

        <div className="listings-nav">

          <Link to="/">
            Home
          </Link>

          <Link to="/browse" className="active">
            Browse
          </Link>

          <Link to="/list-clothing">
            List Clothing
          </Link>

          <Link to="/dashboard">
            Dashboard
          </Link>

          <Link to="/wishlist" className="wishlist-nav-link">
            ❤️ Wishlist

            {wishlist.length > 0 && (
              <span className="wishlist-count">
                {wishlist.length}
              </span>
            )}
          </Link>

          <Link to="/login" className="logout-link">
            Logout
          </Link>

        </div>
      </nav>

      {/* MAIN */}
      <main className="listings-container">

        {/* HEADER */}
        <section className="listings-header">

          <div>

            <span className="section-label">
              EXPLORE
            </span>

            <h1>
              Browse Clothes
            </h1>

            <p>
              Discover clothes from people around you and find your next swap.
            </p>

          </div>

          <Link
            to="/list-clothing"
            className="list-clothing-button"
          >
            + List Clothing
          </Link>

        </section>

        {/* SEARCH & FILTERS */}
        <section className="filters-box">

          <div className="search-wrapper">

            <span>
              🔍
            </span>

            <input
              type="text"
              placeholder="Search clothes, brands..."
            />

          </div>

          <select defaultValue="">
            <option value="">
              All Categories
            </option>

            <option>
              T-Shirt
            </option>

            <option>
              Shirt
            </option>

            <option>
              Jeans
            </option>

            <option>
              Dress
            </option>

            <option>
              Jacket
            </option>

            <option>
              Sweater
            </option>

            <option>
              Shoes
            </option>

            <option>
              Shorts
            </option>
          </select>

          <select defaultValue="">
            <option value="">
              All Sizes
            </option>

            <option>
              S
            </option>

            <option>
              M
            </option>

            <option>
              L
            </option>

            <option>
              32
            </option>

            <option>
              9
            </option>
          </select>

          <select defaultValue="">
            <option value="">
              Condition
            </option>

            <option>
              Like New
            </option>

            <option>
              Excellent
            </option>

            <option>
              Good
            </option>
          </select>

        </section>

        {/* RESULTS */}
        <div className="results-row">

          <p>
            <strong>
              {clothes.length}
            </strong>{" "}
            clothing items available
          </p>

          <select
            className="sort-select"
            defaultValue="latest"
          >
            <option value="latest">
              Sort: Latest
            </option>

            <option value="value-low">
              Value: Low to High
            </option>

            <option value="value-high">
              Value: High to Low
            </option>
          </select>

        </div>

        {/* CLOTHING GRID */}
        <section className="listings-grid">

          {clothes.map((item) => (

            <article
              className="listing-card"
              key={item.id}
            >

              {/* IMAGE */}
              <div className="listing-image">

                <span>
                  {item.emoji}
                </span>

                <span className="condition-badge">
                  {item.condition}
                </span>

                {/* WISHLIST BUTTON */}
                <button
                  type="button"
                  className={`wishlist-button ${
                    isWishlisted(item.id)
                      ? "wishlisted"
                      : ""
                  }`}
                  onClick={() => toggleWishlist(item)}
                  aria-label={
                    isWishlisted(item.id)
                      ? "Remove from wishlist"
                      : "Add to wishlist"
                  }
                  title={
                    isWishlisted(item.id)
                      ? "Remove from wishlist"
                      : "Add to wishlist"
                  }
                >
                  {isWishlisted(item.id) ? "♥" : "♡"}
                </button>

              </div>

              {/* INFORMATION */}
              <div className="listing-info">

                <span className="listing-category">
                  {item.category}
                </span>

                <h2>
                  {item.name}
                </h2>

                <p className="listing-details">
                  {item.brand} • Size {item.size}
                </p>

                <p className="listing-location">
                  📍 {item.location}
                </p>

                {/* FOOTER */}
                <div className="listing-footer">

                  <div>

                    <span>
                      Swap value
                    </span>

                    <strong>
                      ₹{item.value}
                    </strong>

                  </div>

                  <Link
                    to={`/item/${item.id}`}
                    className="view-button"
                  >
                    View
                  </Link>

                </div>

              </div>

            </article>

          ))}

        </section>

      </main>

    </div>
  )
}

export default Listings