
import { Link, useNavigate } from "react-router-dom";
import { useState } from "react";
import "./Auth.css";

import {
  getUsers,
  normalizeEmail,
  saveUsers,
  setCurrentUser,
} from "../utils/storage";

function Register() {
  const navigate = useNavigate();

  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [error, setError] = useState("");

  const handleRegister = (e) => {
    e.preventDefault();
    setError("");

    const cleanName = name.trim();
    const cleanEmail = normalizeEmail(email);

    if (cleanName.length < 2) {
      setError("Please enter your full name.");
      return;
    }

    if (password.length < 6) {
      setError("Password must be at least 6 characters.");
      return;
    }

    if (password !== confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    const users = getUsers();

    const existingUser = users.find(
      (user) => normalizeEmail(user.email) === cleanEmail
    );

    if (existingUser) {
      setError(
        "An account with this email already exists. Please login."
      );
      return;
    }

    const newUser = {
      id: Date.now(),
      name: cleanName,
      email: cleanEmail,
      password,
    };

    const updatedUsers = [...users, newUser];

    if (!saveUsers(updatedUsers)) {
      setError("Unable to create your account. Please try again.");
      return;
    }

    const sessionUser = {
      id: newUser.id,
      name: newUser.name,
      email: newUser.email,
    };

    if (!setCurrentUser(sessionUser)) {
      setError("Account created, but login failed. Please login.");
      return;
    }

    navigate("/dashboard", { replace: true });
  };

  return (
    <div className="auth-page">
      <div className="auth-container">
        <div className="auth-left">
          <div className="auth-logo">♻️ SwapWear</div>

          <h1>
            Join the <span>Movement.</span>
          </h1>

          <p>
            Create your SwapWear account and start
            exchanging clothes with your community
            while reducing textile waste.
          </p>

          <div className="auth-features">
            <div className="auth-feature">
              <div className="auth-feature-icon">✓</div>
              List your clothes
            </div>

            <div className="auth-feature">
              <div className="auth-feature-icon">✓</div>
              Find clothes you love
            </div>

            <div className="auth-feature">
              <div className="auth-feature-icon">✓</div>
              Make simple swaps
            </div>
          </div>
        </div>

        <div className="auth-right">
          <h2>Create Account</h2>

          <p className="auth-subtitle">
            Join SwapWear today
          </p>

          <form className="auth-form" onSubmit={handleRegister}>
            {error && (
              <div
                role="alert"
                style={{
                  padding: "12px 14px",
                  marginBottom: "16px",
                  borderRadius: "8px",
                  background: "#fff1f1",
                  color: "#c0392b",
                  fontSize: "14px",
                }}
              >
                {error}
              </div>
            )}

            <div className="auth-field">
              <label htmlFor="name">Full Name</label>

              <input
                id="name"
                type="text"
                placeholder="Enter your full name"
                value={name}
                onChange={(e) => setName(e.target.value)}
                autoComplete="name"
                required
              />
            </div>

            <div className="auth-field">
              <label htmlFor="email">Email Address</label>

              <input
                id="email"
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                autoComplete="email"
                required
              />
            </div>

            <div className="auth-field">
              <label htmlFor="password">Password</label>

              <input
                id="password"
                type="password"
                placeholder="Create a password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                autoComplete="new-password"
                minLength={6}
                required
              />
            </div>

            <div className="auth-field">
              <label htmlFor="confirmPassword">
                Confirm Password
              </label>

              <input
                id="confirmPassword"
                type="password"
                placeholder="Confirm your password"
                value={confirmPassword}
                onChange={(e) => setConfirmPassword(e.target.value)}
                autoComplete="new-password"
                required
              />
            </div>

            <button type="submit" className="auth-button">
              Create Account
            </button>
          </form>

          <div className="auth-switch">
            Already have an account?{" "}
            <Link to="/login">Login</Link>
          </div>

          <div className="auth-switch">
            <Link to="/">← Back to Home</Link>
          </div>
        </div>
      </div>
    </div>
  );
}

export default Register;
