
import { useState } from "react";
import { Link } from "react-router-dom";

import {
  getCurrentUser,
  getNotifications,
  saveNotifications,
  normalizeEmail,
} from "../utils/storage";

import "./Notifications.css";

function Notifications() {
  const [user] = useState(() => getCurrentUser());
  const [notifications, setNotifications] = useState(() => {
    const currentUser = getCurrentUser();
    if (!currentUser?.email) return [];
    const email = normalizeEmail(currentUser.email);
    return getNotifications().filter(
      (item) =>
        normalizeEmail(item.recipientEmail || "") === email
    );
  });

  const updateNotifications = (updated) => {
    if (!user?.email) return;

    const email = normalizeEmail(user.email);

    const allNotifications = getNotifications();

    const otherUsers = allNotifications.filter(
      (item) =>
        normalizeEmail(item.recipientEmail || "") !== email
    );

    if (!saveNotifications([...otherUsers, ...updated])) {
      alert("Unable to save notification changes.");
      return;
    }

    setNotifications(updated);
  };

  const markAsRead = (id) => {
    const updated = notifications.map((item) =>
      item.id === id ? { ...item, read: true } : item
    );

    updateNotifications(updated);
  };

  const markAllAsRead = () => {
    updateNotifications(
      notifications.map((item) => ({
        ...item,
        read: true,
      }))
    );
  };

  const unreadCount = notifications.filter(
    (item) => !item.read
  ).length;

  return (
    <div className="notifications-page">
      <header className="notifications-navbar">
        <Link to="/" className="notifications-logo">
          ♻️ SwapWear
        </Link>

        <nav>
          <Link to="/browse">Browse</Link>
          <Link to="/dashboard">Dashboard</Link>
          <Link to="/swap-requests">Swap Requests</Link>
        </nav>
      </header>

      <main className="notifications-container">
        <div className="notifications-heading">
          <div>
            <span>STAY UPDATED</span>
            <h1>Notifications 🔔</h1>
            <p>Your latest marketplace updates.</p>
            <p>{unreadCount} unread notifications</p>
          </div>

          {unreadCount > 0 && (
            <button onClick={markAllAsRead}>
              Mark all as read
            </button>
          )}
        </div>

        {notifications.length === 0 ? (
          <div className="notifications-empty">
            <span>🔔</span>
            <h2>No notifications yet</h2>
            <p>
              Updates about your clothing swaps will appear here.
            </p>
            <Link to="/browse">Explore Clothes</Link>
          </div>
        ) : (
          <div className="notifications-list">
            {notifications.map((item) => (
              <article
                key={item.id}
                className={`notification-card ${
                  item.read ? "read" : "unread"
                }`}
              >
                <div className="notification-icon">
                  {item.type === "swap_request"
                    ? "🔄"
                    : item.type === "new_message"
                      ? "💬"
                      : "🔔"}
                </div>

                <div className="notification-content">
                  <h3>{item.title}</h3>
                  <p>{item.message}</p>

                  <small>
                    {new Date(item.createdAt).toLocaleString()}
                  </small>

                  <div className="notification-actions">
                    <Link
                      to={item.link || "/swap-requests"}
                      onClick={() => markAsRead(item.id)}
                    >
                      View Details →
                    </Link>

                    {!item.read && (
                      <button
                        onClick={() => markAsRead(item.id)}
                      >
                        Mark as read
                      </button>
                    )}
                  </div>
                </div>

                {!item.read && (
                  <span className="notification-dot" />
                )}
              </article>
            ))}
          </div>
        )}
      </main>
    </div>
  );
}

export default Notifications;
